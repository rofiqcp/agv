#!/usr/bin/env python3
from gui_source_helper import read_gui_source
"""Static acceptance checks for the BAB IV GUI-only acquisition extension."""

from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
GUI = read_gui_source(ROOT)
SPECS = (ROOT / "gui" / "agv_gui_specs.hpp").read_text(encoding="utf-8")
CATALOG = (ROOT / "gui" / "agv_experiment_catalog.hpp").read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def count_catalog(subsystem: str) -> int:
    return len(re.findall(rf'add\("{re.escape(subsystem)}"', CATALOG))


checks = [
    (count_catalog("navigation") == 34, "navigation catalog must contain 34 reachable N0..N17 commissioning leaves"),
    (count_catalog("perception") == 35, "perception catalog must contain 35 report leaves"),
    (count_catalog("steering") == 22, "ESC/Ackermann catalog must contain 22 ordered report leaves"),
    ('"N16.1"' in CATALOG and '"N17.1"' in CATALOG, "navigation end-to-end and final certified leaves must be covered"),
    (all(token in CATALOG for token in (
        'LEFT — Validasi Encoder ABI TIM4, Hard Stop, Center, dan Home',
        'RIGHT — Validasi Hall, Detect Hall, Arah, dan Pole Pair',
        'LEFT — Tuning PI Arus FOC Steering',
        'RIGHT — Tuning PI Arus FOC Drive',
        'Validasi Geometri Ackermann dengan Steering LEFT dan Velocity RIGHT')),
     "ESC catalog must preserve LEFT encoder, RIGHT Hall, per-motor FOC, and Ackermann dependency order"),
    (all(token in CATALOG for token in ('"Raw TIM4"', '"RIGHT RPM"', '"RIGHT Duty"', '"Yaw rate Ackermann"', '"Yaw-rate error"')),
     "ESC report tables must preserve sensor-specific and Ackermann evidence columns"),
    ("N11.2 Smoother dan Final Global Path Quality" in CATALOG,
     "navigation planner/path-quality evidence leaf must be exposed"),
    ("Gambar 4.1 Diagram alir pipeline sistem persepsi visual" in CATALOG,
     "perception pipeline figure must be exposed"),
    ('"experiment_navigation"' in SPECS and '"experiment_perception"' in SPECS
     and '"experiment_steering"' in SPECS, "three BAB IV acquisition tabs must be registered"),
    ("class ExperimentWorkspacePage" in GUI, "shared acquisition workspace class is missing"),
    ("saveCsvOrdered" in GUI and "savePng" in GUI and '"graph_options"' in GUI,
     "ordered CSV, PNG, and manifest graph choices must be saved"),
    ('"/plan"' in GUI and '"/controller_server/transformed_global_plan"' in GUI,
     "navigation global and controller plan topics must be sampled"),
    ('"/perception/camera_health_state"' in GUI and '"/perception/near_field_state"' in GUI,
     "perception health and near-field topics must be sampled"),
    ('cloud("/perception/drivable_boundary_points","drivable_boundary_points")' in GUI,
     "drivable-boundary point count must be sampled"),
    ('"/esc/foc/telemetry"' in GUI and "Source ESC tidak mempublish" in GUI,
     "FOC telemetry availability must be explicit"),
    ("no estimated report values were injected" in GUI,
     "saved manifest must state that report estimates were not injected"),
]

for condition, message in checks:
    require(condition, message)

print(f"PASS: {len(checks)} BAB IV GUI acquisition checks")
sys.exit(0)
