#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <future>
#include <limits>
#include <memory>
#include <mutex>
#include <optional>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <signal.h>
#include <sys/types.h>
#include <utility>
#include <vector>

#include <QBuffer>
#include <QByteArray>
#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHostAddress>
#include <QImage>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QJsonValue>
#include <QList>
#include <QMap>
#include <QPointer>
#include <QRegularExpression>
#include <QSaveFile>
#include <QSet>
#include <QString>
#include <QStringList>
#include <QTcpServer>
#include <QTcpSocket>
#include <QTimer>
#include <QUrl>
#include <QUrlQuery>

#include <action_msgs/srv/cancel_goal.hpp>
#include <ament_index_cpp/get_package_share_directory.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <geometry_msgs/msg/twist_with_covariance_stamped.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <nav_msgs/msg/path.hpp>
#include <rcl_interfaces/msg/parameter.hpp>
#include <rcl_interfaces/msg/parameter_type.hpp>
#include <rcl_interfaces/srv/get_parameters.hpp>
#include <rcl_interfaces/srv/set_parameters_atomically.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/compressed_image.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <sensor_msgs/msg/nav_sat_fix.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <std_msgs/msg/bool.hpp>
#include <std_msgs/msg/float64.hpp>
#include <std_msgs/msg/float64_multi_array.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_srvs/srv/trigger.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <tf2/time.h>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <yaml-cpp/yaml.h>

#include "agv_experiment_catalog.hpp"

using namespace std::chrono_literals;

namespace {
constexpr double kPi = 3.14159265358979323846;

double nowMs() { return static_cast<double>(QDateTime::currentMSecsSinceEpoch()); }

double yawFromQuat(double x, double y, double z, double w) {
  const double siny = 2.0 * (w * z + x * y);
  const double cosy = 1.0 - 2.0 * (y * y + z * z);
  return std::atan2(siny, cosy);
}

QJsonValue scalarFromString(const QString &value) {
  const QString s = value.trimmed();
  const QString lower = s.toLower();
  if (lower == "true") return true;
  if (lower == "false") return false;
  bool okInt = false;
  const qlonglong integer = s.toLongLong(&okInt);
  if (okInt && !s.contains('.') && !s.contains('e', Qt::CaseInsensitive)) return static_cast<double>(integer);
  bool okDouble = false;
  const double number = s.toDouble(&okDouble);
  if (okDouble && std::isfinite(number)) return number;
  return s;
}

QJsonValue yamlToJson(const YAML::Node &node) {
  if (!node || node.IsNull()) return QJsonValue();
  if (node.IsScalar()) return scalarFromString(QString::fromStdString(node.Scalar()));
  if (node.IsSequence()) {
    QJsonArray array;
    for (const auto &item : node) array.append(yamlToJson(item));
    return array;
  }
  if (node.IsMap()) {
    QJsonObject object;
    for (auto it = node.begin(); it != node.end(); ++it) {
      object.insert(QString::fromStdString(it->first.as<std::string>()), yamlToJson(it->second));
    }
    return object;
  }
  return QJsonValue();
}

QJsonValue rosParameterValueToJson(const rcl_interfaces::msg::ParameterValue &value) {
  using PT = rcl_interfaces::msg::ParameterType;
  switch (value.type) {
    case PT::PARAMETER_BOOL: return value.bool_value;
    case PT::PARAMETER_INTEGER: return static_cast<double>(value.integer_value);
    case PT::PARAMETER_DOUBLE: return value.double_value;
    case PT::PARAMETER_STRING: return QString::fromStdString(value.string_value);
    case PT::PARAMETER_BYTE_ARRAY: { QJsonArray a; for (auto v : value.byte_array_value) a.append(static_cast<double>(v)); return a; }
    case PT::PARAMETER_BOOL_ARRAY: { QJsonArray a; for (auto v : value.bool_array_value) a.append(v); return a; }
    case PT::PARAMETER_INTEGER_ARRAY: { QJsonArray a; for (auto v : value.integer_array_value) a.append(static_cast<double>(v)); return a; }
    case PT::PARAMETER_DOUBLE_ARRAY: { QJsonArray a; for (auto v : value.double_array_value) a.append(v); return a; }
    case PT::PARAMETER_STRING_ARRAY: { QJsonArray a; for (const auto &v : value.string_array_value) a.append(QString::fromStdString(v)); return a; }
    default: return QJsonValue();
  }
}

bool jsonRuntimeEquivalent(const QJsonValue &a, const QJsonValue &b) {
  if (a.isDouble() && b.isDouble()) {
    const double x=a.toDouble(), y=b.toDouble();
    return std::abs(x-y) <= 1e-8 * std::max({1.0,std::abs(x),std::abs(y)});
  }
  if (a.isBool() && b.isBool()) return a.toBool()==b.toBool();
  if (a.isString() && b.isString()) return a.toString()==b.toString();
  if (a.isArray() && b.isArray()) {
    const QJsonArray aa=a.toArray(), bb=b.toArray();
    if (aa.size()!=bb.size()) return false;
    for (int i=0;i<aa.size();++i) if (!jsonRuntimeEquivalent(aa.at(i),bb.at(i))) return false;
    return true;
  }
  return a == b;
}

QString packageConfigDir(const QString &packageName, const char *envName) {
  const QByteArray envValue = qgetenv(envName);
  if (!envValue.trimmed().isEmpty()) {
    const QString path = QDir::cleanPath(QDir::home().absoluteFilePath(QString::fromUtf8(envValue)));
    if (QDir(path).exists()) return path;
    const QString expanded = QString::fromUtf8(envValue).replace("~", QDir::homePath());
    if (QDir(expanded).exists()) return QDir::cleanPath(expanded);
  }
  try {
    const QString share = QString::fromStdString(ament_index_cpp::get_package_share_directory(packageName.toStdString()));
    const QString marker = "/install/";
    const int idx = share.indexOf(marker);
    if (idx > 0) {
      const QString workspace = share.left(idx);
      const QString sourceConfig = workspace + "/src/" + packageName + "/config";
      if (QDir(sourceConfig).exists()) return sourceConfig;
    }
    const QString installed = share + "/config";
    if (QDir(installed).exists()) return installed;
  } catch (...) {
  }
  return QString();
}

QMap<QString, QString> configCandidates() {
  const QString nav = packageConfigDir("navigation", "AGV_CONFIG_DIR");
  const QString esc = packageConfigDir("esc", "AGV_ESC_CONFIG_DIR");
  const QString per = packageConfigDir("perception", "AGV_PERCEPTION_CONFIG_DIR");
  const QString hmi = packageConfigDir("stmf4", "AGV_STMF4_CONFIG_DIR");
  return {
      {"vehicle", nav + "/vehicle.yaml"},
      {"navigation_core", nav + "/navigation_core.yaml"},
      {"nav2", nav + "/nav2_ackermann.yaml"},
      {"ekf", nav + "/ekf.yaml"},
      {"localization", nav + "/localization_cpp.yaml"},
      {"gnss", nav + "/gnss.yaml"},
      {"imu", nav + "/imu.yaml"},
      {"stage3", nav + "/stage3_navigation.yaml"},
      {"trajectory_safety", nav + "/trajectory_safety.yaml"},
      {"collision", nav + "/collision_monitor_production.yaml"},
      {"mppi_closed_loop", nav + "/mppi_closed_loop.yaml"},
      {"gui", nav + "/gui_calibration.yaml"},
      {"esc", esc + "/ackermann.yaml"},
      {"teleop", esc + "/teleop.yaml"},
      {"foc_thesis", esc + "/foc_thesis.yaml"},
      {"hmi", hmi + "/hmi.yaml"},
      {"perception", per + "/astra_yolop_gpu.yaml"},
      {"bbox_calibration", per + "/bbox_obstacle_calibration.yaml"},
  };
}

QJsonObject loadConfigSnapshot() {
  QJsonObject root;
  QJsonObject paths;
  QJsonObject files;
  paths["navigation"] = packageConfigDir("navigation", "AGV_CONFIG_DIR");
  paths["esc"] = packageConfigDir("esc", "AGV_ESC_CONFIG_DIR");
  paths["perception"] = packageConfigDir("perception", "AGV_PERCEPTION_CONFIG_DIR");
  paths["hmi"] = packageConfigDir("stmf4", "AGV_STMF4_CONFIG_DIR");

  const QMap<QString, QString> candidates = configCandidates();
  for (auto it = candidates.cbegin(); it != candidates.cend(); ++it) {
    if (it.value().startsWith('/') && QFileInfo::exists(it.value())) {
      try {
        QJsonObject entry;
        entry["path"] = it.value();
        entry["data"] = yamlToJson(YAML::LoadFile(it.value().toStdString()));
        files[it.key()] = entry;
      } catch (const std::exception &e) {
        files[it.key()] = QJsonObject{{"path", it.value()}, {"error", QString::fromUtf8(e.what())}};
      }
    }
  }
  root["paths"] = paths;
  root["files"] = files;
  root["model_expected"] = "/home/otomasi/ros/models/yolopv2.pt";
  root["generated_at_ms"] = nowMs();
  return root;
}


QString jsonScalarInlineYaml(const QJsonValue &value) {
  if (value.isNull() || value.isUndefined()) return QStringLiteral("~");
  if (value.isBool()) return value.toBool() ? QStringLiteral("true") : QStringLiteral("false");
  if (value.isDouble()) return QString::number(value.toDouble(), 'g', 16);
  if (value.isString()) {
    QJsonArray wrapper{value};
    QByteArray encoded = QJsonDocument(wrapper).toJson(QJsonDocument::Compact);
    return QString::fromUtf8(encoded.mid(1, encoded.size() - 2));
  }
  if (value.isArray()) return QString::fromUtf8(QJsonDocument(value.toArray()).toJson(QJsonDocument::Compact));
  return QString::fromUtf8(QJsonDocument(value.toObject()).toJson(QJsonDocument::Compact));
}

QString jsonScalarPreservingYamlType(const QJsonValue &value, QString originalScalar) {
  originalScalar = originalScalar.trimmed();
  // Preserve floating-point arrays as floating-point arrays. QJson serializes
  // 1.0 as 1, which otherwise changes a ROS 2 double_array into integer_array.
  if (value.isArray() && originalScalar.startsWith('[') && originalScalar.endsWith(']')) {
    static const QRegularExpression floatToken(QStringLiteral(R"([+-]?(?:\d+\.\d*|\d*\.\d+|\d+[eE][+-]?\d+))"));
    if (floatToken.match(originalScalar).hasMatch()) {
      QStringList items;
      for (const QJsonValue &entry : value.toArray()) {
        if (entry.isDouble()) {
          QString n = QString::number(entry.toDouble(), 'g', 16);
          if (!n.contains('.') && !n.contains('e', Qt::CaseInsensitive)) n += QStringLiteral(".0");
          items << n;
        } else {
          items << jsonScalarInlineYaml(entry);
        }
      }
      return QStringLiteral("[") + items.join(QStringLiteral(", ")) + QStringLiteral("]");
    }
  }
  if (!value.isDouble()) return jsonScalarInlineYaml(value);

  // QJson stores every JSON number as double. ROS 2 YAML, however, distinguishes
  // integer and floating-point parameter types. Keep a leaf that was written as
  // 10.0 / 1e-3 in floating-point syntax even when the edited value is exactly
  // integral; otherwise rclcpp rejects the YAML override as PARAMETER_INTEGER.
  static const QRegularExpression floatSyntax(
    QStringLiteral(R"(^[+-]?(?:\d+\.\d*|\d*\.\d+|\d+(?:[eE][+-]?\d+))(?:[eE][+-]?\d+)?$)"));
  const bool originallyFloat = floatSyntax.match(originalScalar).hasMatch();
  QString encoded = QString::number(value.toDouble(), 'g', 16);
  if (originallyFloat && !encoded.contains('.') && !encoded.contains('e', Qt::CaseInsensitive)) {
    encoded += QStringLiteral(".0");
  }
  return encoded;
}

bool patchExistingYamlScalar(const QString &filePath, const QString &yamlPath, const QJsonValue &value, QString *error) {
  QFile in(filePath);
  if (!in.open(QIODevice::ReadOnly | QIODevice::Text)) {
    if (error) *error = QStringLiteral("Tidak dapat membaca YAML");
    return false;
  }
  QStringList lines = QString::fromUtf8(in.readAll()).split('\n');
  in.close();
  const QStringList wanted = yamlPath.split('.', Qt::SkipEmptyParts);
  QVector<QPair<int, QString>> stack;
  int target = -1;
  for (int i = 0; i < lines.size(); ++i) {
    const QString raw = lines[i];
    const QString stripped = raw.trimmed();
    if (stripped.isEmpty() || stripped.startsWith('#') || stripped.startsWith('-') || !stripped.contains(':')) continue;
    const int indent = raw.size() - raw.trimmed().size();
    QString key = stripped.section(':', 0, 0).trimmed();
    key.remove('"'); key.remove('\'');
    while (!stack.isEmpty() && indent <= stack.last().first) stack.removeLast();
    QStringList full;
    for (const auto &entry : stack) full << entry.second;
    full << key;
    if (full == wanted) { target = i; break; }
    stack.push_back({indent, key});
  }
  if (target < 0) {
    if (error) *error = QStringLiteral("Path YAML tidak ditemukan untuk patch preserving-comment");
    return false;
  }
  const QString raw = lines[target];
  const int colon = raw.indexOf(':');
  if (colon < 0) return false;
  const QString prefix = raw.left(colon + 1);
  const QString rest = raw.mid(colon + 1);
  QString comment;
  bool quote = false;
  int hash = -1;
  for (int j = 0; j < rest.size(); ++j) {
    if (rest[j] == '"' && (j == 0 || rest[j - 1] != '\\')) quote = !quote;
    if (rest[j] == '#' && !quote) { hash = j; break; }
  }
  if (hash >= 0) comment = QStringLiteral(" ") + rest.mid(hash).trimmed();
  const QString originalScalar = (hash >= 0 ? rest.left(hash) : rest).trimmed();
  lines[target] = prefix + QStringLiteral(" ") + jsonScalarPreservingYamlType(value, originalScalar) + comment;
  const QByteArray candidate = lines.join('\n').toUtf8();
  try { YAML::Load(candidate.constData()); }
  catch (const std::exception &e) {
    if (error) *error = QStringLiteral("Patch menghasilkan YAML invalid: ") + QString::fromUtf8(e.what());
    return false;
  }
  QSaveFile out(filePath);
  if (!out.open(QIODevice::WriteOnly | QIODevice::Text)) {
    if (error) *error = QStringLiteral("Tidak dapat membuka YAML untuk atomic save");
    return false;
  }
  out.write(candidate);
  if (!out.commit()) {
    if (error) *error = QStringLiteral("Atomic YAML commit gagal");
    return false;
  }
  return true;
}

QJsonValue yamlPathValue(YAML::Node node, const QStringList &parts, int index = 0) {
  if (index >= parts.size() || !node) return yamlToJson(node);
  bool numeric = false;
  const int seqIndex = parts[index].toInt(&numeric);
  if (numeric && node.IsSequence()) {
    if (seqIndex < 0 || static_cast<size_t>(seqIndex) >= node.size()) return QJsonValue();
    return yamlPathValue(node[static_cast<size_t>(seqIndex)], parts, index + 1);
  }
  if (!node.IsMap()) return QJsonValue();
  return yamlPathValue(node[parts[index].toStdString()], parts, index + 1);
}

bool setYamlValueAtomic(const QString &fileKey, const QString &yamlPath, const QJsonValue &input,
                        QString *message, QJsonValue *savedValue = nullptr) {
  const QMap<QString, QString> candidates = configCandidates();
  if (!candidates.contains(fileKey) || yamlPath.trimmed().isEmpty()) {
    if (message) *message = QStringLiteral("file_key/path YAML tidak diizinkan");
    return false;
  }
  const QString filePath = candidates.value(fileKey);
  if (!QFileInfo(filePath).isFile()) {
    if (message) *message = QStringLiteral("File YAML tidak ditemukan: ") + filePath;
    return false;
  }
  const QStringList parts = yamlPath.split('.', Qt::SkipEmptyParts);
  if (parts.isEmpty()) return false;
  try {
    YAML::Node root = YAML::LoadFile(filePath.toStdString());
    YAML::Node current = root;
    for (int i = 0; i < parts.size() - 1; ++i) {
      bool numeric = false;
      const int seqIndex = parts[i].toInt(&numeric);
      if (numeric && current.IsSequence()) {
        if (seqIndex < 0 || static_cast<size_t>(seqIndex) >= current.size()) {
          if (message) *message = QStringLiteral("Index YAML di luar batas");
          return false;
        }
        current = current[static_cast<size_t>(seqIndex)];
      } else {
        if (!current.IsMap() || !current[parts[i].toStdString()]) {
          if (message) *message = QStringLiteral("Path YAML tidak ditemukan: ") + yamlPath;
          return false;
        }
        current = current[parts[i].toStdString()];
      }
    }
    bool lastNumeric = false;
    const int lastIndex = parts.last().toInt(&lastNumeric);
    QString patchPath = yamlPath;
    QJsonValue patchValue = input;
    if (lastNumeric && current.IsSequence()) {
      if (lastIndex < 0 || static_cast<size_t>(lastIndex) >= current.size()) {
        if (message) *message = QStringLiteral("Index YAML di luar batas");
        return false;
      }
      YAML::Node replacement = YAML::Load(jsonScalarInlineYaml(input).toStdString());
      current[static_cast<size_t>(lastIndex)] = replacement;
      patchPath = parts.mid(0, parts.size() - 1).join('.');
      patchValue = yamlToJson(current);
    } else {
      if (!current.IsMap() || !current[parts.last().toStdString()]) {
        if (message) *message = QStringLiteral("Leaf YAML tidak ditemukan: ") + yamlPath;
        return false;
      }
      YAML::Node replacement = YAML::Load(jsonScalarInlineYaml(input).toStdString());
      current[parts.last().toStdString()] = replacement;
    }
    const QString backup = filePath + QStringLiteral(".web.bak.") + QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz");
    if (!QFile::copy(filePath, backup)) {
      if (message) *message = QStringLiteral("Gagal membuat backup YAML");
      return false;
    }
    QString patchError;
    if (!patchExistingYamlScalar(filePath, patchPath, patchValue, &patchError)) {
      QFile::remove(filePath);
      QFile::copy(backup, filePath);
      if (message) *message = patchError;
      return false;
    }
    YAML::Node verified = YAML::LoadFile(filePath.toStdString());
    const QJsonValue actual = yamlPathValue(verified, parts);
    if (savedValue) *savedValue = actual;
    if (message) *message = QStringLiteral("YAML tersimpan atomik; backup: ") + backup +
                            QStringLiteral(". Restart/lifecycle reload mungkin diperlukan.");
    return true;
  } catch (const std::exception &e) {
    if (message) *message = QString::fromUtf8(e.what());
    return false;
  }
}

QString csvEscape(QString value) {
  value.replace('"', QStringLiteral("\"\""));
  return QStringLiteral("\"") + value + QStringLiteral("\"");
}

void flattenJson(const QString &prefix, const QJsonValue &value, QMap<QString, QString> &out, int depth = 0) {
  if (depth > 4) {
    if (value.isObject()) out[prefix] = QString::fromUtf8(QJsonDocument(value.toObject()).toJson(QJsonDocument::Compact));
    else if (value.isArray()) out[prefix] = QString::fromUtf8(QJsonDocument(value.toArray()).toJson(QJsonDocument::Compact));
    return;
  }
  if (value.isObject()) {
    const QJsonObject object = value.toObject();
    for (auto it = object.constBegin(); it != object.constEnd(); ++it) {
      const QString key = prefix.isEmpty() ? it.key() : prefix + QStringLiteral(".") + it.key();
      flattenJson(key, it.value(), out, depth + 1);
    }
    return;
  }
  if (value.isArray()) {
    out[prefix] = QString::fromUtf8(QJsonDocument(value.toArray()).toJson(QJsonDocument::Compact));
  } else if (value.isBool()) out[prefix] = value.toBool() ? QStringLiteral("true") : QStringLiteral("false");
  else if (value.isDouble()) out[prefix] = QString::number(value.toDouble(), 'g', 16);
  else if (value.isString()) out[prefix] = value.toString();
  else out[prefix] = QString();
}

QString recordingCsvStem(QString section) {
  section = section.trimmed();
  if (section.isEmpty()) return QStringLiteral("run");
  const QRegularExpression sectionRx(QStringLiteral(R"(^(\d+(?:\.\d+)*)(?:\s+)?(.*)$)"));
  const QRegularExpressionMatch match = sectionRx.match(section);
  QString prefix;
  QString title = section;
  if (match.hasMatch()) {
    prefix = match.captured(1);
    title = match.captured(2).trimmed();
  }
  title.replace(QRegularExpression(QStringLiteral("\\s+")), QStringLiteral("_"));
  title.replace(QRegularExpression(QStringLiteral("[^A-Za-z0-9._-]+")), QStringLiteral("_"));
  while (title.contains(QStringLiteral("__"))) title.replace(QStringLiteral("__"), QStringLiteral("_"));
  while (title.startsWith('_')) title.remove(0, 1);
  while (title.endsWith('_')) title.chop(1);
  const QString stem = prefix.isEmpty() ? title :
    (title.isEmpty() ? prefix : prefix + QStringLiteral(".") + title);
  return stem.isEmpty() ? QStringLiteral("run") : stem.left(140);
}

QJsonObject parseJsonOrKv(const QString &raw) {
  QJsonParseError error{};
  const QJsonDocument doc = QJsonDocument::fromJson(raw.toUtf8(), &error);
  if (error.error == QJsonParseError::NoError) {
    if (doc.isObject()) return doc.object();
    if (doc.isArray()) return QJsonObject{{"items", doc.array()}, {"raw", raw}};
  }
  QJsonObject out;
  const QStringList parts = raw.split(QRegularExpression("[;,\\n]+"), Qt::SkipEmptyParts);
  for (const QString &part : parts) {
    int sep = part.indexOf('=');
    if (sep <= 0) sep = part.indexOf(':');
    if (sep <= 0) continue;
    const QString key = part.left(sep).trimmed();
    const QString value = part.mid(sep + 1).trimmed();
    if (!key.isEmpty()) out[key] = scalarFromString(value);
  }
  out["raw"] = raw;
  return out;
}

QJsonObject normalizePerceptionPerformance(QJsonObject map) {
  const auto alias = [&map](const QString &target, const QStringList &sources) {
    if (map.contains(target)) return;
    for (const QString &source : sources) if (map.contains(source)) { map[target] = map.value(source); return; }
  };
  alias("fps", {"pipeline_fps", "pipeline_fps_ema"});
  alias("mean_ms", {"pipeline_ms_per_frame", "pipeline_ms"});
  alias("p95_ms", {"pipeline_p95_ms", "pipeline_ms_per_frame", "pipeline_ms"});
  alias("capture_dropped", {"capture_dropped_total"});
  alias("rviz_dropped", {"rviz_dropped_total"});
  alias("raw_count", {"raw_detection_count", "detections"});
  alias("metric_count", {"metric_candidate_count", "object_points"});
  return map;
}

QJsonObject enrichObstacleMetrics(QJsonObject map) {
  const QJsonArray detections = map.value("detections").toArray();
  if (!map.contains("count")) map["count"] = detections.size();
  double nearest = std::numeric_limits<double>::infinity();
  double nearestLeft = std::numeric_limits<double>::quiet_NaN();
  double nearestHomography = std::numeric_limits<double>::quiet_NaN();
  double nearestScore = std::numeric_limits<double>::quiet_NaN();
  int nearestClass = -1, nearestTrack = -1;
  double confidenceSum = 0.0; int confidenceCount = 0;
  for (const auto &entry : detections) {
    const QJsonObject d = entry.toObject();
    const double forward = d.value("forward_m").toDouble(std::numeric_limits<double>::quiet_NaN());
    const double score = d.value("score").toDouble(std::numeric_limits<double>::quiet_NaN());
    if (std::isfinite(score)) {confidenceSum += score; ++confidenceCount;}
    if (std::isfinite(forward) && forward < nearest) {
      nearest = forward; nearestLeft = d.value("left_m").toDouble(std::numeric_limits<double>::quiet_NaN());
      nearestHomography = d.value("forward_homography_m").toDouble(forward);
      nearestScore = score; nearestClass = d.value("class_id").toInt(-1); nearestTrack = d.value("track_id").toInt(-1);
    }
  }
  if (std::isfinite(nearest)) {
    map["nearest_forward_m"] = nearest; map["nearest_left_m"] = nearestLeft;
    map["nearest_forward_homography_m"] = nearestHomography; map["nearest_score"] = nearestScore;
    map["nearest_class_id"] = nearestClass; map["nearest_track_id"] = nearestTrack;
  }
  if (confidenceCount > 0) map["mean_confidence"] = confidenceSum / confidenceCount;
  return map;
}

QJsonObject parseRawDetectionSummary(const QString &raw) {
  QJsonObject map = parseJsonOrKv(raw);
  QJsonArray detections; double confidenceSum = 0.0; int confidenceCount = 0;
  const QRegularExpression cpu(QStringLiteral("d[0-9]+=cls:(-?[0-9]+),score:([-+]?[0-9]*\\.?[0-9]+)"));
  auto matches = cpu.globalMatch(raw);
  while (matches.hasNext()) {
    const auto m = matches.next(); const int cls = m.captured(1).toInt(); const double score = m.captured(2).toDouble();
    detections.append(QJsonObject{{"class_id", cls}, {"score", score}}); confidenceSum += score; ++confidenceCount;
  }
  if (!detections.isEmpty()) {map["detections"] = detections; map["count"] = detections.size();}
  if (confidenceCount > 0) map["mean_confidence"] = confidenceSum / confidenceCount;
  map["raw"] = raw;
  return map;
}

QByteArray mimeTypeForPath(const QString &path) {
  if (path.endsWith(".html")) return "text/html; charset=utf-8";
  if (path.endsWith(".css")) return "text/css; charset=utf-8";
  if (path.endsWith(".js")) return "application/javascript; charset=utf-8";
  if (path.endsWith(".json")) return "application/json; charset=utf-8";
  if (path.endsWith(".svg")) return "image/svg+xml";
  if (path.endsWith(".png")) return "image/png";
  if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
  return "application/octet-stream";
}

QJsonObject experimentCatalogJson() {
  QJsonObject root;
  for (const QString & subsystem : {QStringLiteral("navigation"), QStringLiteral("perception"), QStringLiteral("steering")}) {
    QJsonArray entries;
    for (const ExperimentSpec &spec : buildExperimentCatalog(subsystem)) {
      QJsonObject item;
      item["subsystem"] = spec.subsystem;
      item["groupId"] = spec.groupId;
      item["groupTitle"] = spec.groupTitle;
      item["id"] = spec.id;
      item["section"] = spec.section;
      QJsonArray tableNames;
      for (const QString &name : spec.tableNames) tableNames.append(name);
      item["tableNames"] = tableNames;
      QJsonArray tableColumns;
      for (const QStringList &columns : spec.tableColumns) {
        QJsonArray row;
        for (const QString &column : columns) row.append(column);
        tableColumns.append(row);
      }
      item["tableColumns"] = tableColumns;
      QJsonArray graphCaptions;
      for (const QString &caption : spec.graphCaptions) graphCaptions.append(caption);
      item["graphCaptions"] = graphCaptions;
      QJsonObject liveSeries;
      for (auto it = spec.liveSeries.cbegin(); it != spec.liveSeries.cend(); ++it) liveSeries[it.key()] = it.value();
      item["liveSeries"] = liveSeries;
      QJsonArray parameters;
      for (const ExperimentParameterField &field : spec.parameterFields) {
        parameters.append(QJsonObject{
            {"key", field.key}, {"label", field.label}, {"kind", field.kind},
            {"yamlFileKey", field.yamlFileKey}, {"yamlPath", field.yamlPath},
            {"placeholder", field.placeholder}, {"lockedValue", field.lockedValue},
            {"isGroundTruth", field.isGroundTruth}, {"locked", field.locked}, {"group", field.group}});
      }
      item["parameterFields"] = parameters;
      QJsonArray graphs;
      for (const ExperimentGraphSpec &graph : spec.graphs) {
        QJsonArray series;
        for (const QString &s : graph.series) series.append(s);
        graphs.append(QJsonObject{{"type", graph.type}, {"series", series},
                                  {"xSeries", graph.xSeries}, {"ySeries", graph.ySeries},
                                  {"xLabel", graph.xLabel}, {"yLabel", graph.yLabel}});
      }
      item["graphs"] = graphs;
      entries.append(item);
    }
    root[subsystem] = entries;
  }
  return root;
}

}  // namespace

class WebRosBridge {
 public:
  WebRosBridge() {
    node_ = std::make_shared<rclcpp::Node>("agv_web_gui");
    tfBuffer_ = std::make_unique<tf2_ros::Buffer>(node_->get_clock());
    tfListener_ = std::make_shared<tf2_ros::TransformListener>(*tfBuffer_, node_, false);
    bindAddress_ = QString::fromStdString(node_->declare_parameter<std::string>("bind_address", "127.0.0.1"));
    const auto configuredPort = node_->declare_parameter<std::int64_t>("port", 5000);
    if (configuredPort < 1 || configuredPort > 65535) {
      throw std::invalid_argument("web port must be within 1..65535");
    }
    port_ = static_cast<int>(configuredPort);
    readOnly_ = node_->declare_parameter<bool>("read_only", false);
    cameraJpegFps_ = std::clamp(node_->declare_parameter<double>("camera_jpeg_fps", 5.0), 0.5, 12.0);
    setupRos();
    executor_ = std::make_shared<rclcpp::executors::MultiThreadedExecutor>(rclcpp::ExecutorOptions(), 2);
    executor_->add_node(node_);
    thread_ = std::thread([this]() {
      while (rclcpp::ok() && !stop_.load()) executor_->spin_once(100ms);
    });
    update("server", QJsonObject{{"ros", true}, {"read_only", readOnly_}, {"port", port_},
                                  {"bind_address", bindAddress_}, {"started_at_ms", nowMs()}});
  }

  ~WebRosBridge() {
    stop_.store(true);
    if (executor_) executor_->cancel();
    if (thread_.joinable()) thread_.join();
    if (executor_ && node_) executor_->remove_node(node_);
  }

  QString bindAddress() const { return bindAddress_; }
  int port() const { return port_; }
  bool readOnly() const { return readOnly_; }

  QJsonObject snapshot() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    QJsonObject copy = state_;
    copy["__updated"] = updated_;
    copy["__server_time_ms"] = nowMs();
    return copy;
  }

  QJsonObject takeDelta() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (dirty_.isEmpty()) return {};
    QJsonObject delta;
    QJsonObject timestamps;
    for (const QString &key : dirty_) {
      delta[key] = state_.value(key);
      timestamps[key] = updated_.value(key);
    }
    dirty_.clear();
    delta["__updated"] = timestamps;
    delta["__server_time_ms"] = nowMs();
    return delta;
  }

  QByteArray cameraJpeg() const {
    std::lock_guard<std::mutex> lock(mediaMutex_);
    return cameraJpeg_;
  }

  QByteArray mapPng() const {
    std::lock_guard<std::mutex> lock(mediaMutex_);
    return mapPng_;
  }

  QByteArray globalCostmapPng() const {
    std::lock_guard<std::mutex> lock(mediaMutex_);
    return globalCostmapPng_;
  }

  QByteArray localCostmapPng() const {
    std::lock_guard<std::mutex> lock(mediaMutex_);
    return localCostmapPng_;
  }

  QJsonObject applyConfigChange(const QString &fileKey, const QString &yamlPath) {
    QJsonObject result{{"requested", true}, {"file_key", fileKey}, {"path", yamlPath}};
    const auto targets = runtimeTargetsForChange(fileKey, yamlPath);
    if (targets.isEmpty()) {
      result["mode"] = "yaml_only";
      result["status"] = "NO_RUNTIME_TARGET";
      result["runtime_match"] = false;
      return result;
    }
    QString stationaryReason;
    if (!vehicleStationaryForRuntimeApply(&stationaryReason)) {
      result["mode"] = "restart_when_stationary";
      result["status"] = "PENDING_STATIONARY";
      result["message"] = stationaryReason;
      result["runtime_match"] = false;
      update("runtime_config_apply", result);
      return result;
    }

    QSet<QString> restartNodes;
    for (const auto &target : targets) restartNodes.insert(target.first);
    QJsonArray restartResults;
    int signaled = 0;
    for (const QString &nodeName : restartNodes) {
      const QStringList pids = exactNodeProcesses(nodeName);
      int stopped = 0;
      for (const QString &pidText : pids) {
        bool ok = false;
        const qlonglong pid = pidText.toLongLong(&ok);
        if (ok && pid > 1 && ::kill(pid_t(pid), SIGTERM) == 0) ++stopped;
      }
      signaled += stopped;
      restartResults.append(QJsonObject{{"node", nodeName}, {"matched_processes", pids.size()}, {"signaled", stopped}});
    }
    result["mode"] = "safe_restart";
    result["restart"] = restartResults;
    result["signaled_processes"] = signaled;
    if (signaled == 0) {
      result["status"] = "NEXT_START";
      result["message"] = "Node target tidak sedang berjalan; YAML akan aktif pada start berikutnya.";
      result["runtime_match"] = false;
      update("runtime_config_apply", result);
      return result;
    }

    // Tuning-critical nodes such as perception need time for model load/freeze/warm-up
    // after launch_ros respawn. Poll the parameter service instead of reporting a
    // false RUNTIME_MISMATCH while the constructor is still starting.
    std::this_thread::sleep_for(std::chrono::milliseconds(1500));
    const QString paramName = parameterNameForYamlPath(yamlPath);
    const QJsonValue expected = expectedRuntimeValue(fileKey, yamlPath);
    QJsonArray verify;
    bool allMatch = false;
    int verifyAttempts = 0;
    constexpr int kMaxVerifyAttempts = 8;
    for (int attempt = 1; attempt <= kMaxVerifyAttempts; ++attempt) {
      verifyAttempts = attempt;
      QJsonArray round;
      bool roundMatch = !paramName.isEmpty() && !expected.isUndefined();
      for (const auto &target : targets) {
        const QJsonObject one = readRuntimeParameter(target.second, paramName, expected);
        round.append(one);
        roundMatch = roundMatch && one.value("match").toBool(false);
      }
      verify = round;
      if (roundMatch) { allMatch = true; break; }
      if (attempt < kMaxVerifyAttempts) std::this_thread::sleep_for(std::chrono::milliseconds(900));
    }
    result["verify_attempts"] = verifyAttempts;
    result["verify"] = verify;
    result["runtime_match"] = allMatch;
    result["status"] = allMatch ? "ACTIVE_MATCH" : "RUNTIME_MISMATCH";
    result["message"] = allMatch
        ? QStringLiteral("YAML == runtime; parameter aktif setelah safe restart.")
        : QStringLiteral("Restart terkirim tetapi runtime belum MATCH; jangan mulai run tuning dulu.");
    update("runtime_config_apply", result);
    return result;
  }

  bool publishGoal(double x, double y, double yawRad, QString *message) {
    if (readOnly_) return rejectReadOnly(message);
    if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(yawRad)) {
      if (message) *message = "Koordinat goal tidak valid";
      return false;
    }
    geometry_msgs::msg::PoseStamped goal;
    goal.header.stamp = node_->now();
    goal.header.frame_id = "map";
    goal.pose.position.x = x;
    goal.pose.position.y = y;
    goal.pose.orientation.z = std::sin(yawRad / 2.0);
    goal.pose.orientation.w = std::cos(yawRad / 2.0);
    goalPub_->publish(goal);
    update("goal_pose", QJsonObject{{"x", x}, {"y", y}, {"yaw", yawRad}, {"source", "web"}});
    update("web_action", QJsonObject{{"ok", true}, {"action", "publish_goal"}, {"at_ms", nowMs()}});
    if (message) *message = "Goal diterbitkan ke /navigation/goal_request";
    return true;
  }

  bool publishInitialPose(double x, double y, double yawRad, QString *message) {
    if (readOnly_) return rejectReadOnly(message);
    if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(yawRad)) {
      if (message) *message = "Initial pose tidak valid";
      return false;
    }
    geometry_msgs::msg::PoseWithCovarianceStamped pose;
    pose.header.stamp = node_->now();
    pose.header.frame_id = "map";
    pose.pose.pose.position.x = x;
    pose.pose.pose.position.y = y;
    pose.pose.pose.orientation.z = std::sin(yawRad / 2.0);
    pose.pose.pose.orientation.w = std::cos(yawRad / 2.0);
    pose.pose.covariance[0] = 0.01;
    pose.pose.covariance[7] = 0.01;
    pose.pose.covariance[35] = std::pow(kPi / 180.0, 2);
    initialPosePub_->publish(pose);
    update("web_action", QJsonObject{{"ok", true}, {"action", "publish_initial_pose"}, {"at_ms", nowMs()}});
    if (message) *message = "Initial pose diterbitkan ke /initialpose";
    return true;
  }

  bool cancelNavigation(QString *message) {
    if (readOnly_) return rejectReadOnly(message);
    auto client = node_->create_client<action_msgs::srv::CancelGoal>("/navigate_to_pose/_action/cancel_goal");
    if (!client->wait_for_service(350ms)) {
      if (message) *message = "Service cancel Nav2 belum tersedia";
      return false;
    }
    auto request = std::make_shared<action_msgs::srv::CancelGoal::Request>();
    client->async_send_request(request, [this, client](rclcpp::Client<action_msgs::srv::CancelGoal>::SharedFuture future) {
      try {
        const auto result = future.get();
        const bool ok = result->return_code == 0 || !result->goals_canceling.empty();
        update("web_action", QJsonObject{{"ok", ok}, {"action", "cancel_navigation"},
                                         {"return_code", result->return_code},
                                         {"goals", static_cast<double>(result->goals_canceling.size())},
                                         {"at_ms", nowMs()}});
      } catch (const std::exception &e) {
        update("web_action", QJsonObject{{"ok", false}, {"action", "cancel_navigation"},
                                         {"message", QString::fromUtf8(e.what())}, {"at_ms", nowMs()}});
      }
    });
    if (message) *message = "Permintaan cancel dikirim ke Nav2";
    return true;
  }

  bool triggerService(const QString &service, const QString &tag, QString *message) {
    if (readOnly_) return rejectReadOnly(message);
    auto client = node_->create_client<std_srvs::srv::Trigger>(service.toStdString());
    if (!client->wait_for_service(350ms)) {
      if (message) *message = "Service belum tersedia: " + service;
      return false;
    }
    auto request = std::make_shared<std_srvs::srv::Trigger::Request>();
    client->async_send_request(request, [this, client, service, tag](rclcpp::Client<std_srvs::srv::Trigger>::SharedFuture future) {
      try {
        const auto result = future.get();
        update("web_action", QJsonObject{{"ok", result->success}, {"action", tag}, {"service", service},
                                         {"message", QString::fromStdString(result->message)}, {"at_ms", nowMs()}});
      } catch (const std::exception &e) {
        update("web_action", QJsonObject{{"ok", false}, {"action", tag}, {"service", service},
                                         {"message", QString::fromUtf8(e.what())}, {"at_ms", nowMs()}});
      }
    });
    if (message) *message = "Trigger dikirim ke " + service;
    return true;
  }

  bool publishHmiRequest(const QString &request, QString *message) {
    if (readOnly_) return rejectReadOnly(message);
    const QString cmd = request.trimmed();
    if (cmd.isEmpty() || cmd.size() > 96) {
      if (message) *message = "Perintah HMI tidak valid";
      return false;
    }
    std_msgs::msg::String msg;
    msg.data = cmd.toStdString();
    hmiRequestPub_->publish(msg);
    update("web_action", QJsonObject{{"ok", true}, {"action", "hmi_request"},
                                     {"command", cmd}, {"at_ms", nowMs()}});
    if (message) *message = "Perintah HMI dikirim: " + cmd;
    return true;
  }

  bool setPerceptionInference(bool enabled, QString *message) {
    if (readOnly_) return rejectReadOnly(message);
    auto client = node_->create_client<rcl_interfaces::srv::SetParametersAtomically>("/perception/set_parameters_atomically");
    if (!client->wait_for_service(800ms)) {
      if (message) *message = "Node /perception belum tersedia untuk lazy inference";
      return false;
    }
    auto request = std::make_shared<rcl_interfaces::srv::SetParametersAtomically::Request>();
    rcl_interfaces::msg::Parameter parameter;
    parameter.name = "inference_enabled";
    parameter.value.type = rcl_interfaces::msg::ParameterType::PARAMETER_BOOL;
    parameter.value.bool_value = enabled;
    request->parameters.push_back(parameter);
    client->async_send_request(request,
      [this, client, enabled](rclcpp::Client<rcl_interfaces::srv::SetParametersAtomically>::SharedFuture future) {
        try {
          const auto response = future.get();
          const bool ok = response->result.successful;
          if (ok) update("perception_inference_enabled", enabled);
          update("web_action", QJsonObject{{"ok", ok}, {"action", enabled ? "perception_inference_on" : "perception_inference_off"},
                                           {"message", QString::fromStdString(response->result.reason)}, {"at_ms", nowMs()}});
        } catch (const std::exception &e) {
          update("web_action", QJsonObject{{"ok", false}, {"action", "perception_inference"},
                                           {"message", QString::fromUtf8(e.what())}, {"at_ms", nowMs()}});
        }
      });
    if (message) *message = enabled ? "YOLOPv2 inference diminta ON" : "YOLOPv2 inference diminta OFF (camera-only)";
    return true;
  }

  bool setSteeringCalibrationMode(bool enabled, QString *message) {
    if (readOnly_) return rejectReadOnly(message);
    if (enabled) {
      const double speed = scalarState("esc_drive_actual").value_or(0.0);
      if (std::abs(speed) > 0.05) {
        if (message) *message = QString("Ditolak: kendaraan masih bergerak (%1 m/s)").arg(speed, 0, 'f', 3);
        return false;
      }
    }
    auto client = node_->create_client<rcl_interfaces::srv::SetParametersAtomically>(
        "/esc_ackermann/set_parameters_atomically");
    if (!client->wait_for_service(500ms)) {
      if (message) *message = "Parameter service /esc_ackermann belum tersedia";
      return false;
    }
    auto request = std::make_shared<rcl_interfaces::srv::SetParametersAtomically::Request>();
    rcl_interfaces::msg::Parameter parameter;
    parameter.name = "steering_calibration_mode_enabled";
    parameter.value.type = rcl_interfaces::msg::ParameterType::PARAMETER_BOOL;
    parameter.value.bool_value = enabled;
    request->parameters.push_back(parameter);
    client->async_send_request(
        request, [this, client, enabled](rclcpp::Client<rcl_interfaces::srv::SetParametersAtomically>::SharedFuture future) {
          try {
            const auto result = future.get();
            update("web_action", QJsonObject{{"ok", result->result.successful},
                                             {"action", enabled ? "steering_cal_mode_on" : "steering_cal_mode_off"},
                                             {"message", QString::fromStdString(result->result.reason)}, {"at_ms", nowMs()}});
          } catch (const std::exception &e) {
            update("web_action", QJsonObject{{"ok", false}, {"action", "steering_calibration_mode"},
                                             {"message", QString::fromUtf8(e.what())}, {"at_ms", nowMs()}});
          }
        });
    if (message) *message = enabled ? "Mode kalibrasi steering diminta ON" : "Mode kalibrasi steering diminta OFF";
    return true;
  }

 private:
  rclcpp::Node::SharedPtr node_;
  std::shared_ptr<rclcpp::executors::MultiThreadedExecutor> executor_;
  std::thread thread_;
  std::atomic_bool stop_{false};
  QString bindAddress_;
  int port_{5000};
  bool readOnly_{false};
  double cameraJpegFps_{5.0};
  mutable std::mutex stateMutex_;
  QJsonObject state_;
  QJsonObject updated_;
  QSet<QString> dirty_;
  mutable std::mutex mediaMutex_;
  std::mutex cameraEncodeMutex_;
  std::mutex costmapEncodeMutex_;
  QByteArray cameraJpeg_;
  QByteArray mapPng_;
  QByteArray globalCostmapPng_;
  QByteArray localCostmapPng_;
  std::chrono::steady_clock::time_point lastCameraEncode_{};
  std::chrono::steady_clock::time_point lastRawCameraSeen_{};
  std::chrono::steady_clock::time_point lastCompressedCameraSeen_{};
  std::chrono::steady_clock::time_point lastGlobalCostmapEncode_{};
  std::chrono::steady_clock::time_point lastLocalCostmapEncode_{};
  std::vector<rclcpp::SubscriptionBase::SharedPtr> subscriptions_;
  std::unique_ptr<tf2_ros::Buffer> tfBuffer_;
  std::shared_ptr<tf2_ros::TransformListener> tfListener_;
  rclcpp::TimerBase::SharedPtr tfTimer_;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr goalPub_;
  rclcpp::Publisher<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr initialPosePub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr hmiRequestPub_;

  QVector<QPair<QString,QString>> runtimeTargetsForChange(const QString &fileKey, const QString &path) const {
    QVector<QPair<QString,QString>> out;
    auto add=[&](const QString &restartNode,const QString &parameterNode){out.append(qMakePair(restartNode,parameterNode));};
    if (fileKey == QStringLiteral("ekf")) {
      if (path.startsWith(QStringLiteral("ekf_filter_node_odom."))) add(QStringLiteral("ekf_filter_node_odom"),QStringLiteral("/ekf_filter_node_odom"));
      else if (path.startsWith(QStringLiteral("ekf_filter_node_map."))) add(QStringLiteral("ekf_filter_node_map"),QStringLiteral("/ekf_filter_node_map"));
    } else if (fileKey == QStringLiteral("localization")) add(QStringLiteral("localization_core"),QStringLiteral("/localization_core"));
    else if (fileKey == QStringLiteral("gnss")) add(QStringLiteral("data_cuav_node"),QStringLiteral("/data_cuav_node"));
    else if (fileKey == QStringLiteral("imu")) add(QStringLiteral("data_imu_node"),QStringLiteral("/data_imu_node"));
    else if (fileKey == QStringLiteral("navigation_core")) add(QStringLiteral("navigation_core"),QStringLiteral("/navigation_core"));
    else if (fileKey == QStringLiteral("trajectory_safety")) add(QStringLiteral("trajectory_safety_supervisor"),QStringLiteral("/trajectory_safety_supervisor"));
    else if (fileKey == QStringLiteral("perception")) add(QStringLiteral("perception"),QStringLiteral("/perception"));
    else if (fileKey == QStringLiteral("collision")) add(QStringLiteral("collision_monitor"),QStringLiteral("/collision_monitor"));
    else if (fileKey == QStringLiteral("esc")) add(QStringLiteral("esc_ackermann"),QStringLiteral("/esc_ackermann"));
    else if (fileKey == QStringLiteral("hmi")) add(QStringLiteral("stmf4_hmi_bridge"),QStringLiteral("/stmf4_hmi_bridge"));
    else if (fileKey == QStringLiteral("mppi_closed_loop")) add(QStringLiteral("mppi_closed_loop_supervisor"),QStringLiteral("/mppi_closed_loop_supervisor"));
    else if (fileKey == QStringLiteral("teleop")) add(QStringLiteral("motor_teleop"),QStringLiteral("/motor_teleop"));
    else if (fileKey == QStringLiteral("nav2")) {
      if (path.startsWith(QStringLiteral("planner_server."))) add(QStringLiteral("planner_server"),QStringLiteral("/planner_server"));
      else if (path.startsWith(QStringLiteral("global_costmap."))) add(QStringLiteral("planner_server"),QStringLiteral("/global_costmap/global_costmap"));
      else if (path.startsWith(QStringLiteral("controller_server."))) add(QStringLiteral("controller_server"),QStringLiteral("/controller_server"));
      else if (path.startsWith(QStringLiteral("local_costmap."))) add(QStringLiteral("controller_server"),QStringLiteral("/local_costmap/local_costmap"));
      else if (path.startsWith(QStringLiteral("velocity_smoother."))) add(QStringLiteral("velocity_smoother"),QStringLiteral("/velocity_smoother"));
      else if (path.startsWith(QStringLiteral("behavior_server."))) add(QStringLiteral("behavior_server"),QStringLiteral("/behavior_server"));
      else if (path.startsWith(QStringLiteral("bt_navigator."))) add(QStringLiteral("bt_navigator"),QStringLiteral("/bt_navigator"));
      else if (path.startsWith(QStringLiteral("map_server."))) add(QStringLiteral("map_server"),QStringLiteral("/map_server"));
    }
    // vehicle.yaml is physical authority. The staged GUI exposes those fields
    // locked; runtime fan-out is handled by the native authority synchronizer.
    return out;
  }

  bool vehicleStationaryForRuntimeApply(QString *reason) const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    auto numberAt=[&](const QString &key)->std::optional<double>{
      const QJsonValue value=state_.value(key);
      if (value.isDouble()) return value.toDouble();
      return std::nullopt;
    };
    double cmd=0.0, esc=0.0, wz=0.0;
    const QJsonObject cmdObj=state_.value(QStringLiteral("cmd_final")).toObject();
    if (cmdObj.value(QStringLiteral("linear_x")).isDouble()) cmd=cmdObj.value(QStringLiteral("linear_x")).toDouble();
    if (cmdObj.value(QStringLiteral("angular_z")).isDouble()) wz=cmdObj.value(QStringLiteral("angular_z")).toDouble();
    if (const auto v=numberAt(QStringLiteral("esc_drive_actual"))) esc=*v;
    if (std::abs(cmd)>0.03 || std::abs(esc)>0.03 || std::abs(wz)>0.05) {
      if (reason) *reason=QStringLiteral("Kendaraan/perintah masih bergerak; safe runtime apply menunggu |v|<=0.03 m/s dan |w|<=0.05 rad/s.");
      return false;
    }
    if (reason) reason->clear();
    return true;
  }

  QStringList exactNodeProcesses(const QString &nodeName) const {
    QString bare=nodeName; if (bare.startsWith('/')) bare.remove(0,1);
    QStringList pids;
    QDir proc(QStringLiteral("/proc"));
    for (const QString &pidText : proc.entryList(QDir::Dirs|QDir::NoDotAndDotDot,QDir::Name)) {
      bool ok=false; const qlonglong pid=pidText.toLongLong(&ok);
      if (!ok || pid<=1 || pid==QCoreApplication::applicationPid()) continue;
      QFile f(QStringLiteral("/proc/")+pidText+QStringLiteral("/cmdline"));
      if (!f.open(QIODevice::ReadOnly)) continue;
      QByteArray raw=f.readAll(); raw.replace('\0',' ');
      const QString cmd=QString::fromLocal8Bit(raw);
      if (cmd.contains(QStringLiteral("__node:=")+bare) || cmd.contains(QStringLiteral("__node:=/")+bare)) pids<<pidText;
    }
    return pids;
  }

  QString parameterNameForYamlPath(const QString &yamlPath) const {
    const QString marker=QStringLiteral(".ros__parameters.");
    const int pos=yamlPath.indexOf(marker);
    if (pos<0) return QString();
    QString name=yamlPath.mid(pos+marker.size());
    const QString tail=name.section('.',-1);
    bool numeric=false; tail.toInt(&numeric);
    if (numeric) name=name.section('.',0,-2);
    return name;
  }

  QJsonValue expectedRuntimeValue(const QString &fileKey, const QString &yamlPath) const {
    const auto candidates=configCandidates();
    if (!candidates.contains(fileKey) || !QFileInfo::exists(candidates.value(fileKey))) return QJsonValue(QJsonValue::Undefined);
    QString expectedPath=yamlPath;
    const QString tail=yamlPath.section('.',-1);
    bool numeric=false; tail.toInt(&numeric);
    if (numeric) expectedPath=yamlPath.section('.',0,-2);
    try {
      YAML::Node root=YAML::LoadFile(candidates.value(fileKey).toStdString());
      return yamlPathValue(root, expectedPath.split('.',Qt::SkipEmptyParts));
    } catch (...) { return QJsonValue(QJsonValue::Undefined); }
  }

  QJsonObject readRuntimeParameter(const QString &nodeName, const QString &parameterName, const QJsonValue &expected) {
    QJsonObject out{{"node",nodeName},{"parameter",parameterName},{"expected",expected},{"match",false}};
    if (parameterName.isEmpty()) { out["status"]="NO_PARAMETER_NAME"; return out; }
    auto client=node_->create_client<rcl_interfaces::srv::GetParameters>((nodeName+QStringLiteral("/get_parameters")).toStdString());
    if (!client->wait_for_service(1200ms)) { out["status"]="SERVICE_UNAVAILABLE"; return out; }
    auto request=std::make_shared<rcl_interfaces::srv::GetParameters::Request>();
    request->names.push_back(parameterName.toStdString());
    auto future=client->async_send_request(request);
    if (future.wait_for(1500ms)!=std::future_status::ready) { out["status"]="TIMEOUT"; return out; }
    try {
      const auto response=future.get();
      if (response->values.empty()) { out["status"]="EMPTY_RESPONSE"; return out; }
      const QJsonValue actual=rosParameterValueToJson(response->values.front());
      const bool match=jsonRuntimeEquivalent(expected,actual);
      out["actual"]=actual; out["match"]=match; out["status"]=match?"MATCH":"MISMATCH";
    } catch (const std::exception &e) {
      out["status"]="ERROR"; out["message"]=QString::fromUtf8(e.what());
    }
    return out;
  }

  bool rejectReadOnly(QString *message) const {
    if (message) *message = "Web GUI berjalan dalam read-only mode";
    return false;
  }

  std::optional<double> scalarState(const QString &key) const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    const QJsonValue value = state_.value(key);
    if (!value.isDouble()) return std::nullopt;
    return value.toDouble();
  }

  void update(const QString &channel, const QJsonValue &value) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    state_[channel] = value;
    updated_[channel] = nowMs();
    dirty_.insert(channel);
  }

  template <typename Msg, typename Callback>
  void subscribe(const std::string &topic, const rclcpp::QoS &qos, Callback callback) {
    subscriptions_.push_back(node_->create_subscription<Msg>(topic, qos, callback));
  }

  void setupRos() {
    const auto stateQos = rclcpp::QoS(1).reliable();
    const auto latchedQos = rclcpp::QoS(1).reliable().transient_local();
    const auto sensorQos = rclcpp::QoS(rclcpp::KeepLast(3)).best_effort();

    const std::vector<std::pair<const char *, const char *>> bools = {
        {"/gnss/connected", "connected.gnss"}, {"/imu/connected", "connected.imu"},
        {"/hmi/connected", "connected.hmi"},
        {"/perception/camera_connected", "connected.camera"}, {"/esc/ready", "connected.esc_ready"},
        {"/esc/armed", "connected.esc_armed"}, {"/esc/feedback_valid", "connected.esc_feedback"},
        {"/esc/drive/connected", "connected.esc_drive"}, {"/esc/steer/connected", "connected.esc_steer"},
        {"/esc/steering_calibration/controller_ready", "esc_calibration_controller_ready"},
        {"/system/autonomy_ready", "system.autonomy_ready"}, {"/system/motion_ready", "system.motion_ready"},
        {"/system/planning_localization_ready", "system.planning_localization_ready"},
        {"/system/motion_localization_ready", "system.motion_localization_ready"},
        {"/system/nav2_ready", "system.nav2_ready"},
        {"/navigation/mppi_closed_loop/ready", "mppi_closed_loop_ready"},
        {"/navigation/velocity_smoother/closed_loop_eligible", "smoother_closed_loop_eligible"},
        {"/gnss/velocity_qualified", "gnss_velocity_qualified"}, {"/gnss/cog_qualified", "gnss_cog_qualified"},
        {"/gnss/velocity_fusion_active", "gnss_velocity_fusion_active"},
        {"/gnss/cog_fusion_active", "gnss_cog_fusion_active"},
        {"/perception/camera_healthy", "camera_healthy"},
        {"/perception/emergency_stop", "perception_emergency"}};
    for (const auto &entry : bools) {
      const QString channel = QString::fromLatin1(entry.second);
      subscribe<std_msgs::msg::Bool>(entry.first, latchedQos, [this, channel](std_msgs::msg::Bool::ConstSharedPtr msg) {
        update(channel, msg->data);
      });
    }
    subscribe<std_msgs::msg::Bool>("/safety/estop", stateQos, [this](std_msgs::msg::Bool::ConstSharedPtr msg) {
      update("system.estop", msg->data);
    });

    const std::vector<std::pair<const char *, const char *>> strings = {
        {"/system/localization_state", "localization_state"}, {"/system/gnss_status", "gnss_status"},
        {"/gnss/state", "gnss_driver_state"}, {"/gnss/motion_diagnostics", "gnss_motion"},
        {"/gnss/motion_validation", "gnss_motion_validation"}, {"/gnss/fusion_status", "gnss_fusion_status"},
        {"/system/imu_status", "imu_status"}, {"/system/ekf_local_status", "ekf_local_status"},
        {"/system/ekf_global_status", "ekf_global_status"}, {"/system/pose_estimator", "pose_estimator"},
        {"/system/sensor_status", "sensor_status"}, {"/navigation/goal_state", "goal_state"},
        {"/navigation/mppi_closed_loop/status", "mppi_status"},
        {"/navigation/velocity_smoother/qualification", "smoother_qualification"},
        {"/perception/lane_safety_state", "lane_state"}, {"/perception/lane_control_state", "lane_control"},
        {"/yolop/lane_metrics", "lane_metrics"}, {"/perception/drivable_space", "drivable_space"},
        {"/perception/camera_health_state", "camera_health_state"}, {"/perception/near_field_state", "near_field_state"},
        {"/perception/obstacle_metrics", "obstacle_metrics"}, {"/perception/raw_detections", "raw_detections"},
        {"/perception/semantic_detections", "semantic_detections"},
        {"/perception/semantic_status", "semantic_status"},
        {"/perception/performance", "perception_performance"},
        {"/navigation/trajectory_safety_state", "trajectory_safety_state"},
        {"/collision_monitor/state", "collision_monitor_state"}, {"/esc/status", "esc_status"},
        {"/hmi/page", "hmi_page"}, {"/hmi/operator_mode", "hmi_mode"},
        {"/hmi/camera_tab", "hmi_camera_tab"}, {"/hmi/waypoints", "hmi_waypoints"},
        {"/hmi/navigation_state", "hmi_navigation"},
        {"/hmi/manual_state", "hmi_manual"}, {"/hmi/status", "hmi_status"},
        {"/esc/foc/telemetry", "foc_telemetry"}, {"/esc/mux/active_source", "esc_mux"}};
    for (const auto &entry : strings) {
      const QString channel = QString::fromLatin1(entry.second);
      const QString topic = QString::fromLatin1(entry.first);
      const bool perceptionStream = topic.startsWith(QStringLiteral("/perception/")) ||
                                    topic.startsWith(QStringLiteral("/yolop/"));
      const bool latchedStream = topic.startsWith(QStringLiteral("/hmi/"));
      const rclcpp::QoS & stringQos = perceptionStream ? sensorQos : (latchedStream ? latchedQos : stateQos);
      subscribe<std_msgs::msg::String>(entry.first, stringQos, [this, channel](std_msgs::msg::String::ConstSharedPtr msg) {
        const QString raw = QString::fromStdString(msg->data);
        if (channel == "goal_state") update(channel, QJsonObject{{"state", raw.trimmed().toUpper()}, {"raw", raw}});
        else if (channel == "hmi_page" || channel == "hmi_mode" || channel == "hmi_camera_tab") update(channel, raw.trimmed().toUpper());
        else if (channel == "raw_detections") update(channel, parseRawDetectionSummary(raw));
        else if (channel == "perception_performance") update(channel, normalizePerceptionPerformance(parseJsonOrKv(raw)));
        else if (channel == "obstacle_metrics") update(channel, enrichObstacleMetrics(parseJsonOrKv(raw)));
        else update(channel, parseJsonOrKv(raw));
      });
    }

    subscribe<sensor_msgs::msg::NavSatFix>("/gnss/fix_raw", sensorQos, [this](sensor_msgs::msg::NavSatFix::ConstSharedPtr msg) {
      update("gnss_fix", QJsonObject{{"lat", msg->latitude}, {"lon", msg->longitude}, {"alt", msg->altitude},
                                     {"status", msg->status.status}, {"cov_x", msg->position_covariance[0]},
                                     {"cov_y", msg->position_covariance[4]},
                                     {"measurement_stamp_sec", double(msg->header.stamp.sec) + msg->header.stamp.nanosec * 1e-9}});
    });

    subscribe<std_msgs::msg::Float64MultiArray>("/gnss/quality", sensorQos,
        [this](std_msgs::msg::Float64MultiArray::ConstSharedPtr msg) {
          std::vector<double> data = msg->data;
          data.resize(std::max<size_t>(45, data.size()), std::numeric_limits<double>::quiet_NaN());
          const char *keys[] = {"sat", "dop", "hacc_m", "fix_type", "source_id", "sacc_mps", "ground_speed_mps",
                                "course_enu_rad", "course_accuracy_rad", "itow_ms", "vacc_m", "vel_e_mps", "vel_n_mps",
                                "vel_d_mps", "gdop", "hdop", "vdop", "ndop", "edop", "tdop", "nav_cov_pos_valid",
                                "nav_cov_vel_valid", "pvt_rate_hz", "measurement_age_sec", "timestamp_source_code", "flags2",
                                "flags3", "nav_dop_itow_ms", "nav_dop_exact_epoch", "nav_cov_itow_ms", "nav_cov_exact_epoch",
                                "utc_valid_flags", "tacc_ns", "height_ellipsoid_m", "head_vehicle_enu_rad", "mag_declination_rad",
                                "mag_accuracy_rad", "diff_solution", "carrier_solution", "invalid_llh", "last_correction_age_code",
                                "auth_time", "head_vehicle_valid", "mag_valid", "gnss_fix_ok"};
          QJsonObject object;
          for (int i = 0; i < 45; ++i) {
            if (std::isfinite(data[static_cast<size_t>(i)])) object[keys[i]] = data[static_cast<size_t>(i)];
            else object[keys[i]] = QJsonValue();
          }
          for (const char *key : {"nav_cov_pos_valid", "nav_cov_vel_valid", "nav_dop_exact_epoch", "nav_cov_exact_epoch",
                                  "diff_solution", "invalid_llh", "auth_time", "head_vehicle_valid", "mag_valid", "gnss_fix_ok"}) {
            const QJsonValue value = object.value(key);
            object[key] = value.isDouble() && value.toDouble() > 0.5;
          }
          update("gnss_quality", object);
        });

    const auto velocitySubscribe = [this, sensorQos](const char *topic, const char *channel) {
      const QString ch = QString::fromLatin1(channel);
      subscribe<geometry_msgs::msg::TwistWithCovarianceStamped>(
          topic, sensorQos, [this, ch](geometry_msgs::msg::TwistWithCovarianceStamped::ConstSharedPtr msg) {
            const double vx = msg->twist.twist.linear.x;
            const double vy = msg->twist.twist.linear.y;
            update(ch, QJsonObject{{"vx", vx}, {"vy", vy}, {"vz", msg->twist.twist.linear.z},
                                   {"speed", std::hypot(vx, vy)},
                                   {"course_enu_rad", std::hypot(vx, vy) > 1e-9 ? std::atan2(vy, vx) : 0.0},
                                   {"cov_x", msg->twist.covariance[0]}, {"cov_y", msg->twist.covariance[7]},
                                   {"measurement_stamp_sec", double(msg->header.stamp.sec) + msg->header.stamp.nanosec * 1e-9}});
          });
    };
    velocitySubscribe("/gnss/vel", "gnss_vel");
    velocitySubscribe("/gnss/velocity_position_fit", "gnss_vel_fit");
    velocitySubscribe("/gnss/vel_map", "gnss_vel_map");
    velocitySubscribe("/gnss/base_velocity", "gnss_base_vel");
    velocitySubscribe("/gnss/base_velocity_fusion", "gnss_base_vel_fusion");

    subscribe<geometry_msgs::msg::PoseWithCovarianceStamped>(
        "/gnss/cog_heading_fusion", sensorQos,
        [this](geometry_msgs::msg::PoseWithCovarianceStamped::ConstSharedPtr msg) {
          const auto &q = msg->pose.pose.orientation;
          update("gnss_cog_fusion", QJsonObject{{"yaw_rad", yawFromQuat(q.x, q.y, q.z, q.w)},
                                                 {"yaw_variance", msg->pose.covariance[35]},
                                                 {"measurement_stamp_sec", double(msg->header.stamp.sec) + msg->header.stamp.nanosec * 1e-9}});
        });

    subscribe<sensor_msgs::msg::Imu>("/imu/data", sensorQos, [this](sensor_msgs::msg::Imu::ConstSharedPtr msg) {
      const auto &q = msg->orientation;
      const double sinr = 2 * (q.w * q.x + q.y * q.z);
      const double cosr = 1 - 2 * (q.x * q.x + q.y * q.y);
      const double roll = std::atan2(sinr, cosr);
      const double sinp = 2 * (q.w * q.y - q.z * q.x);
      const double pitch = std::abs(sinp) >= 1 ? std::copysign(kPi / 2, sinp) : std::asin(sinp);
      update("imu", QJsonObject{{"roll_rad", roll}, {"pitch_rad", pitch}, {"yaw_rad", yawFromQuat(q.x, q.y, q.z, q.w)},
                                {"gx", msg->angular_velocity.x}, {"gy", msg->angular_velocity.y}, {"gz", msg->angular_velocity.z},
                                {"ax", msg->linear_acceleration.x}, {"ay", msg->linear_acceleration.y}, {"az", msg->linear_acceleration.z},
                                {"var_roll", msg->orientation_covariance[0]}, {"var_pitch", msg->orientation_covariance[4]},
                                {"var_yaw", msg->orientation_covariance[8]},
                                {"var_gx", msg->angular_velocity_covariance[0]}, {"var_gy", msg->angular_velocity_covariance[4]},
                                {"var_gz", msg->angular_velocity_covariance[8]},
                                {"measurement_stamp_sec", double(msg->header.stamp.sec) + msg->header.stamp.nanosec * 1e-9}});
    });

    const auto odomSubscribe = [this, sensorQos](const char *topic, const char *channel) {
      const QString ch = QString::fromLatin1(channel);
      subscribe<nav_msgs::msg::Odometry>(topic, sensorQos, [this, ch](nav_msgs::msg::Odometry::ConstSharedPtr msg) {
        const auto &p = msg->pose.pose.position;
        const auto &q = msg->pose.pose.orientation;
        update(ch, QJsonObject{{"x", p.x}, {"y", p.y}, {"yaw", yawFromQuat(q.x, q.y, q.z, q.w)},
                               {"v", msg->twist.twist.linear.x}, {"w", msg->twist.twist.angular.z},
                               {"var_x", msg->pose.covariance[0]}, {"var_y", msg->pose.covariance[7]},
                               {"var_yaw", msg->pose.covariance[35]},
                               {"var_v", msg->twist.covariance[0]}, {"var_w", msg->twist.covariance[35]},
                               {"measurement_stamp_sec", double(msg->header.stamp.sec) + msg->header.stamp.nanosec * 1e-9}});
      });
    };
    odomSubscribe("/esc/odom", "esc_odom");
    odomSubscribe("/odometry/gnss_map", "gnss_map_odom");
    odomSubscribe("/odometry/filtered", "ekf_local");
    odomSubscribe("/odometry/filtered_map", "ekf_global");

    const auto pathSubscribe = [this, sensorQos](const char *topic, const char *channel) {
      const QString ch = QString::fromLatin1(channel);
      subscribe<nav_msgs::msg::Path>(topic, sensorQos, [this, ch](nav_msgs::msg::Path::ConstSharedPtr msg) {
        QJsonArray points;
        double length = 0.0;
        double headingVariation = 0.0;
        double previousYaw = 0.0;
        bool havePrevious = false;
        const size_t stride = std::max<size_t>(1, msg->poses.size() / 800 + 1);
        for (size_t i = 0; i < msg->poses.size(); ++i) {
          const auto &p = msg->poses[i].pose.position;
          const auto &q = msg->poses[i].pose.orientation;
          const double yaw = yawFromQuat(q.x, q.y, q.z, q.w);
          if (i > 0) {
            const auto &prev = msg->poses[i - 1].pose.position;
            length += std::hypot(p.x - prev.x, p.y - prev.y);
          }
          if (havePrevious) {
            double d = yaw - previousYaw;
            while (d > kPi) d -= 2 * kPi;
            while (d < -kPi) d += 2 * kPi;
            headingVariation += std::abs(d);
          }
          previousYaw = yaw;
          havePrevious = true;
          if (i % stride == 0 || i + 1 == msg->poses.size()) points.append(QJsonArray{p.x, p.y, yaw});
        }
        update(ch, QJsonObject{{"count", static_cast<double>(msg->poses.size())}, {"length_m", length},
                               {"heading_variation_rad", headingVariation}, {"frame_id", QString::fromStdString(msg->header.frame_id)},
                               {"points", points},
                               {"measurement_stamp_sec", double(msg->header.stamp.sec) + msg->header.stamp.nanosec * 1e-9}});
      });
    };
    pathSubscribe("/plan", "nav_path");
    pathSubscribe("/transformed_global_plan", "local_path");
    pathSubscribe("/controller_server/transformed_global_plan", "local_path");
    pathSubscribe("/local_plan", "local_path");

    // Nav2 Humble MPPI TrajectoryVisualizer publishes a MarkerArray on the
    // controller node's relative `trajectories` topic.  Bridge candidate and
    // optimal trajectories so the browser map can show the same control output
    // that is normally inspected in RViz.
    subscribe<visualization_msgs::msg::MarkerArray>(
      "/trajectories", sensorQos,
      [this](visualization_msgs::msg::MarkerArray::ConstSharedPtr msg) {
        QJsonArray trajectories;
        size_t pointCount = 0;
        size_t optimalCount = 0;
        for (const auto &marker : msg->markers) {
          if (marker.action == visualization_msgs::msg::Marker::DELETE ||
              marker.action == visualization_msgs::msg::Marker::DELETEALL || marker.points.empty()) continue;
          QJsonArray points;
          const size_t stride = std::max<size_t>(1, marker.points.size() / 160 + 1);
          for (size_t i = 0; i < marker.points.size(); ++i) {
            if (i % stride != 0 && i + 1 != marker.points.size()) continue;
            const auto &p = marker.points[i];
            points.append(QJsonArray{p.x, p.y, p.z});
          }
          if (points.size() < 2) continue;
          const QString ns = QString::fromStdString(marker.ns);
          const bool optimal = ns.contains(QStringLiteral("Optimal"), Qt::CaseInsensitive);
          if (optimal) ++optimalCount;
          pointCount += static_cast<size_t>(points.size());
          trajectories.append(QJsonObject{
            {"ns", ns}, {"id", marker.id}, {"frame_id", QString::fromStdString(marker.header.frame_id)},
            {"optimal", optimal}, {"points", points}});
        }
        update("mppi_trajectories", QJsonObject{
          {"count", trajectories.size()}, {"optimal_count", static_cast<double>(optimalCount)},
          {"point_count", static_cast<double>(pointCount)}, {"trajectories", trajectories}});
      });

    const auto goalSubscribe = [this, stateQos](const char *topic) {
      subscribe<geometry_msgs::msg::PoseStamped>(topic, stateQos, [this](geometry_msgs::msg::PoseStamped::ConstSharedPtr msg) {
        const auto &q = msg->pose.orientation;
        update("goal_pose", QJsonObject{{"x", msg->pose.position.x}, {"y", msg->pose.position.y},
                                        {"yaw", yawFromQuat(q.x, q.y, q.z, q.w)}});
      });
    };
    goalSubscribe("/navigation/goal_request");
    goalSubscribe("/goal_pose");

    const auto twistSubscribe = [this, sensorQos](const char *topic, const char *channel) {
      const QString ch = QString::fromLatin1(channel);
      subscribe<geometry_msgs::msg::Twist>(topic, sensorQos, [this, ch](geometry_msgs::msg::Twist::ConstSharedPtr msg) {
        update(ch, QJsonObject{{"linear_x", msg->linear.x}, {"angular_z", msg->angular.z}});
      });
    };
    twistSubscribe("/cmd_vel_nav_raw", "cmd_nav");
    twistSubscribe("/cmd_vel/perception_advisory", "cmd_perception_advisory");
    twistSubscribe("/cmd_vel/autonomy_integrated", "cmd_autonomy_integrated");
    twistSubscribe("/cmd_vel/nav2_pre_collision", "cmd_pre_collision");
    twistSubscribe("/cmd_vel/collision_preview", "cmd_collision_preview");
    twistSubscribe("/cmd_vel", "cmd_final");
    twistSubscribe("/cmd_vel/actuator", "cmd_actuator");

    const std::vector<std::pair<const char *, const char *>> floats = {
        {"/esc/drive_target_mps", "esc_drive_target"}, {"/esc/drive_actual_mps", "esc_drive_actual"},
        {"/esc/steering_target_rad", "esc_steer_target"},
        {"/esc/steering_command_uncalibrated_rad", "esc_steer_uncal_target"},
        {"/esc/steering_uncalibrated_rad", "esc_steer_uncalibrated"},
        {"/esc/steering_protocol_command_rad", "esc_steer_protocol_cmd"},
        {"/esc/steering_feedback_raw_rad", "esc_steer_feedback_raw"},
        {"/esc/steering_actual_rad", "esc_steer_actual"}, {"/esc/yaw_rate_actual_rps", "esc_yaw_rate"},
        {"/esc/kinematic_yaw_rate_rps", "esc_kinematic_yaw_rate"},
        {"/navigation/mppi_closed_loop/velocity_error_mps", "mppi_velocity_error"},
        {"/navigation/mppi_closed_loop/steering_error_rad", "mppi_steering_error"},
        {"/navigation/mppi_closed_loop/yaw_rate_error_rps", "mppi_yaw_error"}};
    for (const auto &entry : floats) {
      const QString channel = QString::fromLatin1(entry.second);
      subscribe<std_msgs::msg::Float64>(entry.first, sensorQos, [this, channel](std_msgs::msg::Float64::ConstSharedPtr msg) {
        update(channel, msg->data);
      });
    }

    subscribe<sensor_msgs::msg::CompressedImage>("/camera/astra/image_preview/compressed", sensorQos,
      [this](sensor_msgs::msg::CompressedImage::ConstSharedPtr msg) {
        if (!msg || msg->data.empty()) return;
        const auto now = std::chrono::steady_clock::now();
        {
          std::lock_guard<std::mutex> lock(mediaMutex_);
          cameraJpeg_ = QByteArray(reinterpret_cast<const char *>(msg->data.data()), static_cast<int>(msg->data.size()));
        }
        {
          std::lock_guard<std::mutex> encodeLock(cameraEncodeMutex_);
          lastCompressedCameraSeen_ = now;
          lastCameraEncode_ = now;
        }
        const QString format = QString::fromStdString(msg->format);
        const QString source = format.contains(QStringLiteral("yolop_annotated")) ?
          QStringLiteral("yolop_annotated") : QStringLiteral("camera_raw");
        update("camera_frame", QJsonObject{{"encoding", "jpeg"}, {"source", source}, {"format", format}, {"at_ms", nowMs()},
                                            {"bytes", static_cast<double>(msg->data.size())}});
      });

    auto cacheCamera = [this](sensor_msgs::msg::Image::ConstSharedPtr msg, const QString &source) {
      // Raw and annotated image subscriptions may execute concurrently in the
      // MultiThreadedExecutor. Serialize throttle/encode state to avoid racing
      // lastCameraEncode_ and producing duplicate JPEG work on the mini-PC.
      std::lock_guard<std::mutex> encodeLock(cameraEncodeMutex_);
      const auto now = std::chrono::steady_clock::now();
      if (lastCompressedCameraSeen_.time_since_epoch().count() != 0 &&
          std::chrono::duration<double>(now - lastCompressedCameraSeen_).count() < 1.0) return;
      if (source == QStringLiteral("raw")) lastRawCameraSeen_ = now;
      const double elapsed = std::chrono::duration<double>(now - lastCameraEncode_).count();
      if (lastCameraEncode_.time_since_epoch().count() != 0 && elapsed < 1.0 / cameraJpegFps_) return;
      if (msg->width == 0 || msg->height == 0 || msg->step == 0) return;
      const std::uint64_t requiredBytes = static_cast<std::uint64_t>(msg->step) * static_cast<std::uint64_t>(msg->height);
      if (requiredBytes > msg->data.size()) return;
      QImage image;
      if (msg->encoding == "rgb8" && msg->step >= msg->width * 3U) {
        image = QImage(msg->data.data(), static_cast<int>(msg->width), static_cast<int>(msg->height),
                       static_cast<int>(msg->step), QImage::Format_RGB888).copy();
      } else if (msg->encoding == "bgr8" && msg->step >= msg->width * 3U) {
        image = QImage(msg->data.data(), static_cast<int>(msg->width), static_cast<int>(msg->height),
                       static_cast<int>(msg->step), QImage::Format_RGB888).rgbSwapped().copy();
      } else if ((msg->encoding == "mono8" || msg->encoding == "8UC1") && msg->step >= msg->width) {
        image = QImage(msg->data.data(), static_cast<int>(msg->width), static_cast<int>(msg->height),
                       static_cast<int>(msg->step), QImage::Format_Grayscale8).copy();
      }
      if (image.isNull()) return;
      QByteArray encoded;
      QBuffer buffer(&encoded);
      if (!buffer.open(QIODevice::WriteOnly) || !image.save(&buffer, "JPG", 78) || encoded.isEmpty()) return;
      {
        std::lock_guard<std::mutex> lock(mediaMutex_);
        cameraJpeg_ = encoded;
      }
      lastCameraEncode_ = now;
      update("camera_frame", QJsonObject{{"width", static_cast<int>(msg->width)}, {"height", static_cast<int>(msg->height)},
                                         {"encoding", QString::fromStdString(msg->encoding)}, {"source", source}, {"at_ms", nowMs()}});
    };
    subscribe<sensor_msgs::msg::Image>("/camera/astra/image_raw", sensorQos,
                                      [cacheCamera](sensor_msgs::msg::Image::ConstSharedPtr msg) { cacheCamera(msg, "raw"); });
    subscribe<sensor_msgs::msg::Image>("/camera/yolop/image_annotated", sensorQos,
                                      [cacheCamera](sensor_msgs::msg::Image::ConstSharedPtr msg) { cacheCamera(msg, "annotated"); });

    subscribe<nav_msgs::msg::OccupancyGrid>("/map", latchedQos, [this](nav_msgs::msg::OccupancyGrid::ConstSharedPtr msg) {
      if (msg->info.width == 0 || msg->info.height == 0 || msg->data.empty()) return;
      const std::uint64_t cellCount = static_cast<std::uint64_t>(msg->info.width) * static_cast<std::uint64_t>(msg->info.height);
      if (cellCount > msg->data.size() || cellCount > 100000000ULL ||
          msg->info.width > static_cast<unsigned int>(std::numeric_limits<int>::max()) ||
          msg->info.height > static_cast<unsigned int>(std::numeric_limits<int>::max())) return;
      QImage image(static_cast<int>(msg->info.width), static_cast<int>(msg->info.height), QImage::Format_Grayscale8);
      if (image.isNull()) return;
      for (unsigned int y = 0; y < msg->info.height; ++y) {
        uchar *row = image.scanLine(static_cast<int>(msg->info.height - 1 - y));
        for (unsigned int x = 0; x < msg->info.width; ++x) {
          const int8_t occ = msg->data[static_cast<size_t>(y) * msg->info.width + x];
          int shade = 118;
          if (occ >= 0) shade = std::clamp(245 - static_cast<int>(occ) * 2, 35, 245);
          row[x] = static_cast<uchar>(shade);
        }
      }
      QByteArray encoded;
      QBuffer buffer(&encoded);
      if (!buffer.open(QIODevice::WriteOnly) || !image.save(&buffer, "PNG") || encoded.isEmpty()) return;
      {
        std::lock_guard<std::mutex> lock(mediaMutex_);
        mapPng_ = encoded;
      }
      const auto &origin = msg->info.origin.position;
      update("map_meta", QJsonObject{{"width", static_cast<int>(msg->info.width)}, {"height", static_cast<int>(msg->info.height)},
                                     {"resolution", msg->info.resolution}, {"origin_x", origin.x}, {"origin_y", origin.y},
                                     {"frame_id", QString::fromStdString(msg->header.frame_id)}, {"at_ms", nowMs()}});
    });

    // RViz-like costmap layers for the Web HMI. These are the actual Nav2
    // OccupancyGrid outputs, not a fabricated inflation preview. Encoding is
    // throttled and downsampled to keep the mini-PC responsive on large maps.
    const auto cacheCostmap = [this, latchedQos](const char *topic, const char *metaKey, bool global) {
      subscribe<nav_msgs::msg::OccupancyGrid>(topic, latchedQos,
        [this, metaKey, global](nav_msgs::msg::OccupancyGrid::ConstSharedPtr msg) {
          if (msg->info.width == 0 || msg->info.height == 0 || msg->data.empty()) return;
          const std::uint64_t cells = static_cast<std::uint64_t>(msg->info.width) * msg->info.height;
          if (cells > msg->data.size() || cells > 100000000ULL) return;

          std::lock_guard<std::mutex> encodeLock(costmapEncodeMutex_);
          auto &last = global ? lastGlobalCostmapEncode_ : lastLocalCostmapEncode_;
          const auto now = std::chrono::steady_clock::now();
          const double minPeriod = global ? 1.0 : 0.25;
          if (last.time_since_epoch().count() != 0 &&
              std::chrono::duration<double>(now - last).count() < minPeriod) return;

          constexpr unsigned int kMaxRaster = 1600U;
          const unsigned int largest = std::max(msg->info.width, msg->info.height);
          const unsigned int stride = std::max(1U, (largest + kMaxRaster - 1U) / kMaxRaster);
          const unsigned int outW = (msg->info.width + stride - 1U) / stride;
          const unsigned int outH = (msg->info.height + stride - 1U) / stride;
          QImage image(static_cast<int>(outW), static_cast<int>(outH), QImage::Format_RGBA8888);
          if (image.isNull()) return;
          image.fill(Qt::transparent);

          for (unsigned int oy = 0; oy < outH; ++oy) {
            uchar *row = image.scanLine(static_cast<int>(outH - 1U - oy));
            for (unsigned int ox = 0; ox < outW; ++ox) {
              int maxCost = -1;
              const unsigned int y0 = oy * stride;
              const unsigned int x0 = ox * stride;
              const unsigned int y1 = std::min(msg->info.height, y0 + stride);
              const unsigned int x1 = std::min(msg->info.width, x0 + stride);
              for (unsigned int y = y0; y < y1; ++y) {
                const size_t base = static_cast<size_t>(y) * msg->info.width;
                for (unsigned int x = x0; x < x1; ++x) maxCost = std::max(maxCost, static_cast<int>(msg->data[base + x]));
              }
              uchar *px = row + static_cast<size_t>(ox) * 4U;
              if (maxCost <= 0) { px[0]=0; px[1]=0; px[2]=0; px[3]=0; continue; }
              const int bounded = std::clamp(maxCost, 1, 100);
              const int alpha = std::clamp(42 + bounded * 2, 48, 225);
              if (bounded >= 90) { px[0]=255; px[1]=72; px[2]=88; }
              else if (bounded >= 50) { px[0]=255; px[1]=159; px[2]=64; }
              else { px[0]=181; px[1]=119; px[2]=255; }
              px[3]=static_cast<uchar>(alpha);
            }
          }

          QByteArray encoded;
          QBuffer buffer(&encoded);
          if (!buffer.open(QIODevice::WriteOnly) || !image.save(&buffer, "PNG") || encoded.isEmpty()) return;
          {
            std::lock_guard<std::mutex> lock(mediaMutex_);
            if (global) globalCostmapPng_ = encoded; else localCostmapPng_ = encoded;
          }
          last = now;
          const auto &origin = msg->info.origin.position;
          update(QString::fromLatin1(metaKey), QJsonObject{
            {"width", static_cast<int>(msg->info.width)}, {"height", static_cast<int>(msg->info.height)},
            {"image_width", static_cast<int>(outW)}, {"image_height", static_cast<int>(outH)},
            {"stride", static_cast<int>(stride)}, {"resolution", msg->info.resolution},
            {"origin_x", origin.x}, {"origin_y", origin.y},
            {"frame_id", QString::fromStdString(msg->header.frame_id)}, {"at_ms", nowMs()}});
        });
    };
    cacheCostmap("/global_costmap/costmap", "global_costmap_meta", true);
    cacheCostmap("/local_costmap/costmap", "local_costmap_meta", false);

    const auto cloudSubscribe = [this, sensorQos](const char *topic, const char *channel) {
      const QString ch = QString::fromLatin1(channel);
      subscribe<sensor_msgs::msg::PointCloud2>(topic, sensorQos, [this, ch](sensor_msgs::msg::PointCloud2::ConstSharedPtr msg) {
        update(ch, QJsonObject{{"count", static_cast<double>(msg->width) * static_cast<double>(msg->height)},
                               {"frame_id", QString::fromStdString(msg->header.frame_id)}});
      });
    };
    cloudSubscribe("/perception/object_points", "object_points");
    cloudSubscribe("/perception/path_relevant_points", "path_relevant_points");
    cloudSubscribe("/perception/planning_relevant_points", "planning_relevant_points");
    cloudSubscribe("/perception/drivable_boundary_points", "drivable_boundary_points");

    // Fixed-frame transform used to place the odom-frame local costmap exactly
    // where RViz would render it in the map frame. Failure is non-fatal while
    // localization is starting; the Web layer simply remains WAIT.
    tfTimer_ = node_->create_wall_timer(200ms, [this]() {
      if (!tfBuffer_) return;
      try {
        const auto tf = tfBuffer_->lookupTransform("map", "odom", tf2::TimePointZero);
        update("map_odom_tf", QJsonObject{{"x", tf.transform.translation.x}, {"y", tf.transform.translation.y},
          {"yaw", yawFromQuat(tf.transform.rotation.x, tf.transform.rotation.y,
                              tf.transform.rotation.z, tf.transform.rotation.w)},
          {"at_ms", nowMs()}});
      } catch (const std::exception &) {
        // Expected during STARTUP/DEGRADED localization.
      }
    });

    goalPub_ = node_->create_publisher<geometry_msgs::msg::PoseStamped>("/navigation/goal_request", 10);
    initialPosePub_ = node_->create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>("/initialpose", 10);
    hmiRequestPub_ = node_->create_publisher<std_msgs::msg::String>("/hmi/request", 10);
  }
};

class LocalHttpServer : public QObject {
 public:
  LocalHttpServer(WebRosBridge *bridge, QObject *parent = nullptr) : QObject(parent), bridge_(bridge) {
    connect(&server_, &QTcpServer::newConnection, this, [this]() { acceptConnections(); });
    eventTimer_.setInterval(200);
    connect(&eventTimer_, &QTimer::timeout, this, [this]() { broadcastEvents(); });
    recordingTimer_.setInterval(200);
    connect(&recordingTimer_, &QTimer::timeout, this, [this]() { captureRecordingSample(); });
  }

  bool start(const QString &bindAddress, int port) {
    QHostAddress address;
    if (!address.setAddress(bindAddress)) {
      if (bindAddress == "localhost") address = QHostAddress::LocalHost;
      else return false;
    }
    if (!server_.listen(address, static_cast<quint16>(port))) return false;
    try {
      staticRoot_ = QString::fromStdString(ament_index_cpp::get_package_share_directory("navigation")) + "/web/static";
    } catch (...) {
      staticRoot_.clear();
    }
    const QString envRoot = QString::fromUtf8(qgetenv("AGV_WEB_STATIC_DIR"));
    if (!envRoot.isEmpty() && QDir(envRoot).exists()) staticRoot_ = envRoot;
    const QString canonicalRoot = QFileInfo(staticRoot_).canonicalFilePath();
    if (canonicalRoot.isEmpty() || !QFileInfo(canonicalRoot + "/index.html").isFile()) {
      server_.close();
      staticRoot_.clear();
      return false;
    }
    staticRoot_ = canonicalRoot;
    eventTimer_.start();
    return true;
  }

 private:
  struct Request {
    QByteArray method;
    QString path;
    QMap<QByteArray, QByteArray> headers;
    QByteArray body;
  };

  WebRosBridge *bridge_{nullptr};
  QTcpServer server_;
  QTimer eventTimer_;
  QTimer recordingTimer_;
  QList<QPointer<QTcpSocket>> sseClients_;
  QString staticRoot_;
  int heartbeatTicks_{0};
  bool recording_{false};
  QString recordingSubsystem_;
  QString recordingId_;
  QString recordingSourceExperimentId_;
  QString recordingLabel_;
  QString recordingSectionLabel_;
  QMap<QString, QString> recordingTuningConfig_;
  QString recordingVariation_;
  QString recordingCondition_;
  QString recordingStartedIso_;
  qint64 recordingStartedMs_{0};
  double recordingRateHz_{5.0};
  QVector<QMap<QString, QString>> recordingRows_;
  QByteArray lastDownloadCsv_;
  QString lastDownloadName_;

  void acceptConnections() {
    while (server_.hasPendingConnections()) {
      QTcpSocket *socket = server_.nextPendingConnection();
      socket->setProperty("request_buffer", QByteArray());
      connect(socket, &QTcpSocket::readyRead, this, [this, socket]() { readRequest(socket); });
      connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
    }
  }

  void readRequest(QTcpSocket *socket) {
    if (!socket || socket->property("sse").toBool()) return;
    QByteArray buffer = socket->property("request_buffer").toByteArray();
    buffer += socket->readAll();
    const int headerEnd = buffer.indexOf("\r\n\r\n");
    if (headerEnd < 0) {
      if (buffer.size() > 64 * 1024) {
        sendJson(socket, 413, QJsonObject{{"ok", false}, {"message", "Request headers too large"}});
      } else {
        socket->setProperty("request_buffer", buffer);
      }
      return;
    }
    if (headerEnd > 64 * 1024) {
      return sendJson(socket, 413, QJsonObject{{"ok", false}, {"message", "Request headers too large"}});
    }
    const QByteArray headersPart = buffer.left(headerEnd);
    const QList<QByteArray> lines = headersPart.split('\n');
    if (lines.isEmpty()) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Bad request"}});
    const QList<QByteArray> first = lines.first().trimmed().split(' ');
    if (first.size() < 2) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Bad request line"}});
    Request request;
    request.method = first[0].trimmed();
    const QUrl url = QUrl::fromEncoded(first[1]);
    request.path = url.path();
    for (int i = 1; i < lines.size(); ++i) {
      const QByteArray line = lines[i].trimmed();
      const int colon = line.indexOf(':');
      if (colon > 0) request.headers[line.left(colon).trimmed().toLower()] = line.mid(colon + 1).trimmed();
    }
    bool ok = false;
    const int contentLength = request.headers.value("content-length", "0").toInt(&ok);
    const int bodyStart = headerEnd + 4;
    if (!ok || contentLength < 0 || contentLength > 256 * 1024) {
      return sendJson(socket, 413, QJsonObject{{"ok", false}, {"message", "Request body too large or invalid"}});
    }
    if (contentLength > 0 && buffer.size() < bodyStart + contentLength) {
      socket->setProperty("request_buffer", buffer);
      return;
    }
    if (contentLength > 0) request.body = buffer.mid(bodyStart, contentLength);
    handle(socket, request);
  }

  void handle(QTcpSocket *socket, const Request &request) {
    if (request.method == "GET" && request.path == "/api/events") return openSse(socket);
    if (request.method == "GET" && request.path == "/api/state") return sendJson(socket, 200, bridge_->snapshot());
    if (request.method == "GET" && request.path == "/api/health") {
      return sendJson(socket, 200, QJsonObject{{"ok", true}, {"ros", true}, {"read_only", bridge_->readOnly()},
                                               {"server_time_ms", nowMs()}});
    }
    if (request.method == "GET" && request.path == "/api/experiments") return sendJson(socket, 200, experimentCatalogJson());
    if (request.method == "GET" && request.path == "/api/config") return sendJson(socket, 200, loadConfigSnapshot());
    if (request.method == "GET" && request.path == "/api/experiment/record/status") {
      return sendJson(socket, 200, recordingStatus());
    }
    if (request.method == "GET" && request.path == "/api/camera.jpg") {
      const QByteArray bytes = bridge_->cameraJpeg();
      if (bytes.isEmpty()) return sendText(socket, 503, "text/plain; charset=utf-8", "Camera frame belum tersedia");
      return sendBytes(socket, 200, "image/jpeg", bytes, {{"Cache-Control", "no-store, max-age=0"}});
    }
    if (request.method == "GET" && request.path == "/api/map.png") {
      const QByteArray bytes = bridge_->mapPng();
      if (bytes.isEmpty()) return sendText(socket, 503, "text/plain; charset=utf-8", "Map belum tersedia");
      return sendBytes(socket, 200, "image/png", bytes, {{"Cache-Control", "no-store, max-age=0"}});
    }
    if (request.method == "GET" && request.path == "/api/global_costmap.png") {
      const QByteArray bytes = bridge_->globalCostmapPng();
      if (bytes.isEmpty()) return sendText(socket, 503, "text/plain; charset=utf-8", "Global costmap belum aktif");
      return sendBytes(socket, 200, "image/png", bytes, {{"Cache-Control", "no-store, max-age=0"}});
    }
    if (request.method == "GET" && request.path == "/api/local_costmap.png") {
      const QByteArray bytes = bridge_->localCostmapPng();
      if (bytes.isEmpty()) return sendText(socket, 503, "text/plain; charset=utf-8", "Local costmap belum aktif");
      return sendBytes(socket, 200, "image/png", bytes, {{"Cache-Control", "no-store, max-age=0"}});
    }
    if (request.method == "GET" && request.path == "/api/experiment/record/last.csv") {
      if (lastDownloadCsv_.isEmpty()) return sendText(socket, 404, "text/plain; charset=utf-8", "Belum ada CSV hasil Stop pada sesi server ini");
      const QByteArray disposition = QByteArray("attachment; filename=\"") + lastDownloadName_.toUtf8() + "\"";
      return sendBytes(socket, 200, "text/csv; charset=utf-8", lastDownloadCsv_,
                       {{"Cache-Control", "no-store"}, {"Content-Disposition", disposition}});
    }
    if (request.method == "POST") return handlePost(socket, request);
    if (request.method == "GET") return serveStatic(socket, request.path);
    sendJson(socket, 405, QJsonObject{{"ok", false}, {"message", "Method not allowed"}});
  }

  void handlePost(QTcpSocket *socket, const Request &request) {
    QJsonParseError error{};
    const QJsonDocument doc = QJsonDocument::fromJson(request.body, &error);
    if (!request.body.isEmpty() && (error.error != QJsonParseError::NoError || !doc.isObject())) {
      return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "JSON body tidak valid"}});
    }
    const QJsonObject json = doc.isObject() ? doc.object() : QJsonObject();
    QString message;
    bool ok = false;
    if (request.path == "/api/config/set") {
      if (bridge_->readOnly()) {
        return sendJson(socket, 403, QJsonObject{{"ok", false}, {"message", "Web GUI read-only; perubahan YAML ditolak"}});
      }
      const QString fileKey=json.value("file_key").toString();
      const QString yamlPath=json.value("path").toString();
      QJsonValue saved;
      ok = setYamlValueAtomic(fileKey, yamlPath, json.value("value"), &message, &saved);
      QJsonObject runtimeApply;
      if (ok) runtimeApply=bridge_->applyConfigChange(fileKey,yamlPath);
      const QString runtimeStatus=runtimeApply.value("status").toString();
      const QString combined=ok
          ? message + QStringLiteral(" Runtime: ") + runtimeStatus + QStringLiteral(". ") + runtimeApply.value("message").toString()
          : message;
      return sendJson(socket, ok ? 200 : 409, QJsonObject{{"ok", ok}, {"message", combined},
                       {"file_key", fileKey}, {"path", yamlPath}, {"saved_value", saved},
                       {"runtime_apply", runtimeApply}, {"runtime_match", runtimeApply.value("runtime_match")},
                       {"config", loadConfigSnapshot()}, {"at_ms", nowMs()}});
    } else if (request.path == "/api/experiment/record/start") {
      ok = startRecording(json, &message);
      return sendJson(socket, ok ? 200 : 409, QJsonObject{{"ok", ok}, {"message", message},
                       {"recording", recordingStatus()}, {"at_ms", nowMs()}});
    } else if (request.path == "/api/experiment/record/stop") {
      QJsonObject result;
      ok = stopRecording(&message, &result);
      result["ok"] = ok; result["message"] = message; result["at_ms"] = nowMs();
      return sendJson(socket, ok ? 200 : 409, result);
    } else if (request.path == "/api/experiment/table/save") {
      QJsonObject result;
      ok = saveTemplateTable(json, &message, &result);
      result["ok"] = ok; result["message"] = message; result["at_ms"] = nowMs();
      return sendJson(socket, ok ? 200 : 409, result);
    } else if (request.path == "/api/perception/inference") {
      ok = bridge_->setPerceptionInference(json.value("enabled").toBool(false), &message);
    } else if (request.path == "/api/navigation/goal") {
      ok = bridge_->publishGoal(json.value("x").toDouble(std::numeric_limits<double>::quiet_NaN()),
                                json.value("y").toDouble(std::numeric_limits<double>::quiet_NaN()),
                                json.contains("yaw_rad") ? json.value("yaw_rad").toDouble() : json.value("yaw_deg").toDouble() * kPi / 180.0,
                                &message);
    } else if (request.path == "/api/navigation/cancel") {
      ok = bridge_->cancelNavigation(&message);
    } else if (request.path == "/api/localization/initial-pose") {
      ok = bridge_->publishInitialPose(json.value("x").toDouble(std::numeric_limits<double>::quiet_NaN()),
                                       json.value("y").toDouble(std::numeric_limits<double>::quiet_NaN()),
                                       json.contains("yaw_rad") ? json.value("yaw_rad").toDouble() : json.value("yaw_deg").toDouble() * kPi / 180.0,
                                       &message);
    } else if (request.path == "/api/hmi/page") {
      const QString page = json.value("page").toString().trimmed().toUpper();
      static const QSet<QString> allowed{QStringLiteral("HOME"), QStringLiteral("CAMERA"), QStringLiteral("GPS"), QStringLiteral("ACTUATOR")};
      if (!allowed.contains(page)) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Page HMI tidak valid"}});
      ok = bridge_->publishHmiRequest("PAGE:" + page, &message);
    } else if (request.path == "/api/hmi/camera-tab") {
      const QString tab = json.value("tab").toString().trimmed().toUpper();
      static const QSet<QString> allowedTabs{QStringLiteral("VIEW"), QStringLiteral("DETECT"), QStringLiteral("DRIVE"), QStringLiteral("STATUS")};
      if (!allowedTabs.contains(tab)) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Camera tab HMI tidak valid"}});
      ok = bridge_->publishHmiRequest("CAMERA_TAB:" + tab, &message);
    } else if (request.path == "/api/hmi/waypoint/select") {
      const int index = json.value("index").toInt(-1);
      if (index < 0 || index > 3) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Waypoint index wajib 0..3"}});
      ok = bridge_->publishHmiRequest(QString("WAYPOINT:SELECT:%1").arg(index), &message);
    } else if (request.path == "/api/hmi/waypoint/save") {
      const int index = json.value("index").toInt(-1);
      QString name = json.value("name").toString().trimmed().left(18);
      name.remove(QRegularExpression(QStringLiteral("[^A-Za-z0-9 _-]")));
      if (index < 0 || index > 3) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Waypoint index wajib 0..3"}});
      const QString command = name.isEmpty() ? QString("WAYPOINT:SAVE:%1").arg(index) : QString("WAYPOINT:SAVE:%1:%2").arg(index).arg(name);
      ok = bridge_->publishHmiRequest(command, &message);
    } else if (request.path == "/api/hmi/waypoint/go") {
      const int index = json.value("index").toInt(-1);
      if (index < 0 || index > 3) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Waypoint index wajib 0..3"}});
      ok = bridge_->publishHmiRequest(QString("WAYPOINT:GO:%1").arg(index), &message);
    } else if (request.path == "/api/hmi/navigation/stop") {
      ok = bridge_->publishHmiRequest("NAV:STOP", &message);
    } else if (request.path == "/api/hmi/mode") {
      const QString mode = json.value("mode").toString().trimmed().toUpper();
      if (mode != "AUTO" && mode != "MANUAL") return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Mode HMI wajib AUTO/MANUAL"}});
      ok = bridge_->publishHmiRequest("MODE:" + mode, &message);
    } else if (request.path == "/api/hmi/control") {
      const QString action = json.value("action").toString().trimmed().toUpper();
      static const QSet<QString> drive{QStringLiteral("FWD"), QStringLiteral("REV"), QStringLiteral("STOP")};
      static const QSet<QString> steer{QStringLiteral("LEFT"), QStringLiteral("CENTER"), QStringLiteral("RIGHT")};
      if (drive.contains(action)) ok = bridge_->publishHmiRequest("DRIVE:" + action, &message);
      else if (steer.contains(action)) ok = bridge_->publishHmiRequest("STEER:" + action, &message);
      else return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Control HMI tidak valid"}});
    } else if (request.path == "/api/hmi/speed") {
      const int pct = json.value("pct").toInt(-1);
      if (pct < 10 || pct > 50 || pct % 10 != 0) return sendJson(socket, 400, QJsonObject{{"ok", false}, {"message", "Speed HMI wajib 10/20/30/40/50%"}});
      ok = bridge_->publishHmiRequest(QString("SPEED:%1").arg(pct), &message);
    } else if (request.path == "/api/hmi/sync") {
      ok = bridge_->publishHmiRequest("SYNC", &message);
    } else if (request.path == "/api/localization/reset-calibration") {
      ok = bridge_->triggerService("/localization/reset_calibration_samples", "reset_localization_calibration", &message);
    } else if (request.path == "/api/steering/calibration-mode") {
      ok = bridge_->setSteeringCalibrationMode(json.value("enabled").toBool(false), &message);
    } else {
      return sendJson(socket, 404, QJsonObject{{"ok", false}, {"message", "Unknown API endpoint"}});
    }
    sendJson(socket, ok ? 200 : 409, QJsonObject{{"ok", ok}, {"message", message}, {"at_ms", nowMs()}});
  }

  QJsonObject recordingStatus() const {
    return QJsonObject{{"active", recording_}, {"subsystem", recordingSubsystem_}, {"id", recordingId_},
                       {"source_experiment_id", recordingSourceExperimentId_},
                       {"label", recordingLabel_}, {"section_label", recordingSectionLabel_},
                       {"variation", recordingVariation_}, {"condition", recordingCondition_},
                       {"started_at", recordingStartedIso_}, {"sample_rate_hz", recordingRateHz_},
                       {"elapsed_s", recording_ && recordingStartedMs_ > 0 ? (nowMs() - recordingStartedMs_) / 1000.0 : 0.0},
                       {"samples", recordingRows_.size()},
                       {"report_root", QStringLiteral("/home/otomasi/ros/data")}};
  }

  bool startRecording(const QJsonObject &json, QString *message) {
    if (recording_) {
      if (message) *message = QStringLiteral("Recording lain masih aktif; Stop CSV lebih dulu");
      return false;
    }
    const QString subsystem = json.value("subsystem").toString().trimmed();
    const QString id = json.value("id").toString().trimmed();
    if (!QStringList{QStringLiteral("navigation"), QStringLiteral("perception"), QStringLiteral("steering")}.contains(subsystem) || id.isEmpty()) {
      if (message) *message = QStringLiteral("subsystem/id recording tidak valid");
      return false;
    }
    recordingSubsystem_ = subsystem;
    recordingId_ = id;
    recordingSourceExperimentId_ = json.value("source_experiment_id").toString().trimmed();
    if (recordingSourceExperimentId_.isEmpty()) recordingSourceExperimentId_ = recordingId_;
    recordingLabel_ = json.value("label").toString().trimmed();
    if (recordingLabel_.isEmpty()) recordingLabel_ = recordingId_;
    recordingSectionLabel_ = json.value("section_label").toString().trimmed();
    if (recordingSectionLabel_.isEmpty()) recordingSectionLabel_ = recordingLabel_;
    recordingTuningConfig_.clear();
    const QJsonObject tuningConfig = json.value("tuning_config").toObject();
    for (auto it = tuningConfig.constBegin(); it != tuningConfig.constEnd(); ++it) {
      flattenJson(QStringLiteral("tuning_yaml.") + it.key(), it.value(), recordingTuningConfig_);
    }
    recordingVariation_ = json.value("variation").toString().trimmed();
    recordingCondition_ = json.value("condition").toString().trimmed();
    recordingRateHz_ = std::clamp(json.value("sample_rate_hz").toDouble(5.0), 1.0, 20.0);
    recordingStartedIso_ = QDateTime::currentDateTime().toString(Qt::ISODateWithMs);
    recordingStartedMs_ = nowMs();
    recordingRows_.clear();
    recording_ = true;
    recordingTimer_.start(std::max(50, static_cast<int>(std::lround(1000.0 / recordingRateHz_))));
    captureRecordingSample();
    if (message) *message = QStringLiteral("CSV recording dimulai: ") + subsystem + QStringLiteral("/") + id;
    return true;
  }

  void captureRecordingSample() {
    if (!recording_ || !bridge_) return;
    QMap<QString, QString> row;
    const qint64 sampleMs = nowMs();
    row["time_iso"] = QDateTime::currentDateTime().toString(Qt::ISODateWithMs);
    row["elapsed_s"] = QString::number(recordingStartedMs_ > 0 ? (sampleMs - recordingStartedMs_) / 1000.0 : 0.0, 'f', 3);
    row["subsystem"] = recordingSubsystem_;
    row["section_id"] = recordingId_;
    row["source_experiment_id"] = recordingSourceExperimentId_;
    row["section_label"] = recordingSectionLabel_;
    row["variation"] = recordingVariation_;
    row["condition"] = recordingCondition_;
    for (auto it = recordingTuningConfig_.cbegin(); it != recordingTuningConfig_.cend(); ++it) row[it.key()] = it.value();
    const QJsonObject snap = bridge_->snapshot();
    for (auto it = snap.constBegin(); it != snap.constEnd(); ++it) {
      if (it.key().startsWith(QStringLiteral("__"))) continue;
      flattenJson(it.key(), it.value(), row);
    }
    recordingRows_.push_back(row);
    if (recordingRows_.size() > 250000) {
      recording_ = false;
      recordingTimer_.stop();
    }
  }

  bool saveTemplateTable(const QJsonObject &json, QString *message, QJsonObject *result) {
    const QString subsystem = json.value("subsystem").toString().trimmed();
    const QString id = json.value("id").toString().trimmed();
    const QString label = json.value("label").toString().trimmed();
    const int tableIndex = std::max(0, json.value("table_index").toInt(0));
    const QString csvText = json.value("csv").toString();
    if (!QStringList{QStringLiteral("navigation"), QStringLiteral("perception"), QStringLiteral("steering")}.contains(subsystem) ||
        id.isEmpty() || csvText.trimmed().isEmpty()) {
      if (message) *message = QStringLiteral("Template table payload tidak valid");
      return false;
    }
    const QString domain = subsystem == QStringLiteral("navigation") ? QStringLiteral("navigasi") :
                           subsystem == QStringLiteral("perception") ? QStringLiteral("presepsi") : QStringLiteral("esc");
    const QString dataRoot = QDir(QStringLiteral("/home/otomasi/ros/data")).filePath(domain);
    if (!QDir().mkpath(dataRoot)) {
      if (message) *message = QStringLiteral("Gagal membuat folder data: ") + dataRoot;
      return false;
    }
    const QString stemLabel = id.isEmpty() ? label : id;
    const QString minuteStamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    const QString baseStem = recordingCsvStem(stemLabel) + QStringLiteral("_T%1_").arg(tableIndex + 1) + minuteStamp;
    QString fileName = baseStem + QStringLiteral(".csv");
    int suffix = 2;
    while (QFileInfo::exists(QDir(dataRoot).filePath(fileName)))
      fileName = baseStem + QStringLiteral("_%1.csv").arg(suffix++, 2, 10, QChar('0'));
    const QString path = QDir(dataRoot).filePath(fileName);
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
      if (message) *message = QStringLiteral("Gagal membuka template CSV: ") + path;
      return false;
    }
    file.write(csvText.toUtf8());
    if (!file.commit()) {
      if (message) *message = QStringLiteral("Gagal commit template CSV: ") + path;
      return false;
    }
    if (result) *result = QJsonObject{{"path", path}, {"table_index", tableIndex}, {"section_id", id}, {"subsystem", subsystem}};
    if (message) *message = QStringLiteral("Template table CSV tersimpan: ") + path;
    return true;
  }

  bool saveRecordingFiles(QJsonObject *result, QString *message) {
    if (recordingRows_.isEmpty()) {
      if (message) *message = QStringLiteral("Tidak ada sampel untuk disimpan");
      return false;
    }

    const QString domain = recordingSubsystem_ == QStringLiteral("navigation") ? QStringLiteral("navigasi") :
                           recordingSubsystem_ == QStringLiteral("perception") ? QStringLiteral("presepsi") :
                           QStringLiteral("esc");
    const QString dataRoot = QDir(QStringLiteral("/home/otomasi/ros/data")).filePath(domain);
    if (!QDir().mkpath(dataRoot)) {
      if (message) *message = QStringLiteral("Gagal membuat folder data: ") + dataRoot;
      return false;
    }

    QSet<QString> all;
    for (const auto &row : recordingRows_) {
      for (auto it = row.cbegin(); it != row.cend(); ++it) all.insert(it.key());
    }
    QStringList columns = all.values();
    std::sort(columns.begin(), columns.end());
    for (const QString &preferred : {QStringLiteral("condition"), QStringLiteral("variation"),
                                      QStringLiteral("section_label"), QStringLiteral("source_experiment_id"),
                                      QStringLiteral("section_id"), QStringLiteral("subsystem"),
                                      QStringLiteral("elapsed_s"), QStringLiteral("time_iso")}) {
      columns.removeAll(preferred);
    }
    columns.prepend(QStringLiteral("condition"));
    columns.prepend(QStringLiteral("variation"));
    columns.prepend(QStringLiteral("section_label"));
    columns.prepend(QStringLiteral("source_experiment_id"));
    columns.prepend(QStringLiteral("section_id"));
    columns.prepend(QStringLiteral("subsystem"));
    columns.prepend(QStringLiteral("elapsed_s"));
    columns.prepend(QStringLiteral("time_iso"));

    QByteArray csv;
    QStringList escapedHeader;
    for (const QString &column : columns) escapedHeader << csvEscape(column);
    csv += escapedHeader.join(',').toUtf8() + '\n';
    for (const auto &row : recordingRows_) {
      QStringList values;
      for (const QString &column : columns) values << csvEscape(row.value(column));
      csv += values.join(',').toUtf8() + '\n';
    }

    const QString minuteStamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    const QString baseStem = recordingCsvStem(recordingId_) + QStringLiteral("_") + minuteStamp;
    QString fileName = baseStem + QStringLiteral(".csv");
    int suffix = 2;
    while (QFileInfo::exists(QDir(dataRoot).filePath(fileName))) {
      fileName = baseStem + QStringLiteral("_%1.csv").arg(suffix++, 2, 10, QChar('0'));
    }
    const QString primaryPath = QDir(dataRoot).filePath(fileName);
    QSaveFile csvFile(primaryPath);
    if (!csvFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
      if (message) *message = QStringLiteral("Gagal membuka CSV: ") + primaryPath;
      return false;
    }
    csvFile.write(csv);
    if (!csvFile.commit()) {
      if (message) *message = QStringLiteral("Gagal commit CSV: ") + primaryPath;
      return false;
    }

    // Browser download memakai buffer memory yang sama; tidak membuat summary,
    // manifest, config JSON, atau folder run tambahan di /home/otomasi/ros/data.
    lastDownloadCsv_ = csv;
    lastDownloadName_ = fileName;
    if (result) {
      *result = QJsonObject{{"subsystem", recordingSubsystem_}, {"section_id", recordingId_},
                           {"source_experiment_id", recordingSourceExperimentId_},
                           {"section_label", recordingSectionLabel_}, {"sample_count", recordingRows_.size()},
                           {"primary_csv", primaryPath}, {"raw_csv", primaryPath},
                           {"report_root", dataRoot},
                           {"download_url", QStringLiteral("/api/experiment/record/last.csv")},
                           {"download_name", lastDownloadName_}};
    }
    if (message) {
      *message = QStringLiteral("CSV tersimpan: ") + primaryPath +
                 QStringLiteral("; download browser siap");
    }
    return true;
  }

  bool stopRecording(QString *message, QJsonObject *result) {
    if (!recording_) {
      if (message) *message = QStringLiteral("Tidak ada CSV recording aktif");
      return false;
    }
    captureRecordingSample();
    recording_ = false;
    recordingTimer_.stop();
    const bool saved = saveRecordingFiles(result, message);
    recordingRows_.clear();
    return saved;
  }

  void openSse(QTcpSocket *socket) {
    QByteArray headers;
    headers += "HTTP/1.1 200 OK\r\n";
    headers += "Content-Type: text/event-stream\r\n";
    headers += "Cache-Control: no-cache, no-transform\r\n";
    headers += "Connection: keep-alive\r\n";
    headers += "X-Accel-Buffering: no\r\n\r\n";
    socket->write(headers);
    socket->setProperty("sse", true);
    sseClients_.append(QPointer<QTcpSocket>(socket));
    const QByteArray snapshot = QJsonDocument(bridge_->snapshot()).toJson(QJsonDocument::Compact);
    socket->write("event: snapshot\ndata: " + snapshot + "\n\n");
    socket->flush();
  }

  void broadcastEvents() {
    for (int i = sseClients_.size() - 1; i >= 0; --i) {
      if (sseClients_[i].isNull() || sseClients_[i]->state() != QAbstractSocket::ConnectedState) sseClients_.removeAt(i);
    }
    const QJsonObject delta = bridge_->takeDelta();
    QByteArray payload;
    if (!delta.isEmpty()) payload = "data: " + QJsonDocument(delta).toJson(QJsonDocument::Compact) + "\n\n";
    ++heartbeatTicks_;
    const bool heartbeat = heartbeatTicks_ >= 50;
    if (heartbeat) heartbeatTicks_ = 0;
    for (const auto &client : sseClients_) {
      if (client.isNull()) continue;
      if (client->bytesToWrite() > 2 * 1024 * 1024) continue;
      if (!payload.isEmpty()) client->write(payload);
      if (heartbeat) client->write(": heartbeat\n\n");
    }
  }

  void serveStatic(QTcpSocket *socket, QString path) {
    if (path == "/") path = "/index.html";
    if (path.contains("..")) return sendJson(socket, 403, QJsonObject{{"ok", false}, {"message", "Forbidden"}});
    if (staticRoot_.isEmpty()) return sendJson(socket, 500, QJsonObject{{"ok", false}, {"message", "Static web root tidak ditemukan"}});
    // Use lexical containment instead of canonicalFilePath() for the requested
    // file.  With colcon --symlink-install, static assets are symlinks into src/;
    // canonicalizing the file resolves outside install/share and incorrectly
    // rejects valid files as 404.  '..' is already rejected above and the
    // cleaned absolute path must remain inside the trusted static root.
    const QString cleanRoot = QDir::cleanPath(QDir(staticRoot_).absolutePath());
    const QString cleanFile = QDir::cleanPath(QDir(cleanRoot).absoluteFilePath(path.mid(1)));
    const QString rootPrefix = cleanRoot.endsWith(QDir::separator()) ? cleanRoot : cleanRoot + QDir::separator();
    if (!cleanFile.startsWith(rootPrefix) || !QFileInfo(cleanFile).isFile()) {
      return sendJson(socket, 404, QJsonObject{{"ok", false}, {"message", "Not found"}});
    }
    QFile file(cleanFile);
    if (!file.open(QIODevice::ReadOnly)) return sendJson(socket, 404, QJsonObject{{"ok", false}, {"message", "Not found"}});
    sendBytes(socket, 200, mimeTypeForPath(cleanFile), file.readAll(), {{"Cache-Control", "no-cache"}});
  }

  static QByteArray statusText(int status) {
    switch (status) {
      case 200: return "OK";
      case 400: return "Bad Request";
      case 403: return "Forbidden";
      case 404: return "Not Found";
      case 405: return "Method Not Allowed";
      case 409: return "Conflict";
      case 413: return "Payload Too Large";
      case 500: return "Internal Server Error";
      case 503: return "Service Unavailable";
      default: return "Response";
    }
  }

  void sendJson(QTcpSocket *socket, int status, const QJsonObject &json) {
    sendBytes(socket, status, "application/json; charset=utf-8", QJsonDocument(json).toJson(QJsonDocument::Compact),
              {{"Cache-Control", "no-store"}});
  }

  void sendText(QTcpSocket *socket, int status, const QByteArray &contentType, const QByteArray &text) {
    sendBytes(socket, status, contentType, text, {{"Cache-Control", "no-store"}});
  }

  void sendBytes(QTcpSocket *socket, int status, const QByteArray &contentType, const QByteArray &body,
                 const QMap<QByteArray, QByteArray> &extra = {}) {
    QByteArray headers = "HTTP/1.1 " + QByteArray::number(status) + " " + statusText(status) + "\r\n";
    headers += "Content-Type: " + contentType + "\r\n";
    headers += "Content-Length: " + QByteArray::number(body.size()) + "\r\n";
    headers += "Connection: close\r\n";
    headers += "X-Content-Type-Options: nosniff\r\n";
    headers += "Referrer-Policy: no-referrer\r\n";
    headers += "Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'\r\n";
    for (auto it = extra.cbegin(); it != extra.cend(); ++it) headers += it.key() + ": " + it.value() + "\r\n";
    headers += "\r\n";
    socket->write(headers);
    socket->write(body);
    socket->disconnectFromHost();
  }
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  QCoreApplication app(argc, argv);
  QCoreApplication::setApplicationName("AGV Web GUI");
  QCoreApplication::setApplicationVersion("1.0");
  int result = 1;
  try {
    WebRosBridge bridge;
    LocalHttpServer server(&bridge);
    if (!server.start(bridge.bindAddress(), bridge.port())) {
      RCLCPP_ERROR(rclcpp::get_logger("agv_web_gui"), "Gagal listen web GUI pada %s:%d",
                   bridge.bindAddress().toUtf8().constData(), bridge.port());
    } else {
      RCLCPP_INFO(rclcpp::get_logger("agv_web_gui"), "Web GUI aktif: http://%s:%d%s",
                  bridge.bindAddress().toUtf8().constData(), bridge.port(), bridge.readOnly() ? " [READ ONLY]" : "");
      if (bridge.bindAddress() != "127.0.0.1" && bridge.bindAddress() != "::1" && bridge.bindAddress() != "localhost") {
        RCLCPP_WARN(rclcpp::get_logger("agv_web_gui"),
                    "Web GUI di-bind non-loopback. Gunakan jaringan tepercaya; endpoint kontrol tidak memakai autentikasi eksternal.");
      }
      QTimer rosShutdownGuard;
      rosShutdownGuard.setInterval(200);
      QObject::connect(&rosShutdownGuard, &QTimer::timeout, &app, [&app]() {
        if (!rclcpp::ok()) app.quit();
      });
      rosShutdownGuard.start();
      result = app.exec();
    }
  } catch (const std::exception &e) {
    RCLCPP_FATAL(rclcpp::get_logger("agv_web_gui"), "Web GUI fatal: %s", e.what());
  }
  if (rclcpp::ok()) rclcpp::shutdown();
  return result;
}
