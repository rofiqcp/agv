// Implementation file for experiment_components.hpp.
// This file is #included as a translation unit from agv_gui.cpp AFTER all local
// widget/store classes (ReportPlotWidget, YamlStore, etc.) are fully defined.
// Keeping method bodies here (not inline in the header) avoids "incomplete type"
// errors when moc compiles the header.
#include "experiment_components.hpp"
#include <QHBoxLayout>
#include <QKeyEvent>
#include <QVBoxLayout>

// ============================================================
// GraphCard implementation
// ============================================================
GraphCard::GraphCard(const QString &title, QWidget *parent)
: QWidget(parent), title_(title) {
  auto *layout = new QVBoxLayout(this);
  layout->setContentsMargins(0, 0, 0, 0);
  layout->setSpacing(4);
  auto *header = new QHBoxLayout();
  titleLabel_ = new QLabel(title);
  titleLabel_->setObjectName(QStringLiteral("graphCardTitle"));
  header->addWidget(titleLabel_, 1);
  maximize_ = new QPushButton(QStringLiteral("⛶"));
  maximize_->setObjectName(QStringLiteral("graphCardMaximize"));
  maximize_->setFixedSize(26, 22);
  maximize_->setToolTip(QStringLiteral("Perbesar grafik ke layar penuh"));
  header->addWidget(maximize_);
  layout->addLayout(header);
  plot_ = new ReportPlotWidget();
  plot_->setMinimumHeight(220);
  layout->addWidget(plot_, 1);
  connect(maximize_, &QPushButton::clicked, this, [this]() {
    emit maximizeRequested();
  });
}

void GraphCard::setTitle(const QString &t) {
  title_ = t;
  titleLabel_->setText(t);
}

void GraphCard::setData(const QString &title, const QString &xLabel, const QString &yLabel,
const QMap<QString, QVector<QPointF>> &series, bool connectPoints, const QString &emptyMessage) {
  plot_->setPlot(title, xLabel, yLabel, series, connectPoints, emptyMessage);
}

void GraphCard::clear() {
  plot_->clear();
}

ReportPlotWidget *GraphCard::plot() const {
  return plot_;
}

// ============================================================
// GraphFullscreenDialog implementation
// ============================================================
GraphFullscreenDialog::GraphFullscreenDialog(const QString &title, QWidget *parent)
: QDialog(parent) {
  setWindowTitle(title);
  setWindowFlags(windowFlags() | Qt::WindowMaximizeButtonHint);
  auto *layout = new QVBoxLayout(this);
  layout->setContentsMargins(8, 8, 8, 8);
  plot_ = new ReportPlotWidget();
  plot_->setMinimumHeight(400);
  layout->addWidget(plot_, 1);
  setMinimumSize(640, 480);
  resize(1100, 720);
}

void GraphFullscreenDialog::updateData(const QString &title, const QString &xLabel, const QString &yLabel,
const QMap<QString, QVector<QPointF>> &series, bool connectPoints, const QString &emptyMessage) {
  plot_->setPlot(title, xLabel, yLabel, series, connectPoints, emptyMessage);
}

void GraphFullscreenDialog::keyPressEvent(QKeyEvent *e) {
  if (e->key() == Qt::Key_Escape) {
    accept();
    return;
  }
  QDialog::keyPressEvent(e);
}

// ============================================================
// ExperimentParameterPanel implementation
// ============================================================
ExperimentParameterPanel::ExperimentParameterPanel(QWidget *parent) : QWidget(parent) {
  auto *layout = new QVBoxLayout(this);
  layout->setContentsMargins(6, 6, 6, 6);
  layout->setSpacing(6);
  header_ = new QLabel(QStringLiteral("Pengujian Aktif"));
  header_->setObjectName(QStringLiteral("paramPanelHeader"));
  layout->addWidget(header_);
  scroll_ = new QScrollArea();
  scroll_->setWidgetResizable(true);
  scroll_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  container_ = new QWidget();
  containerLayout_ = new QVBoxLayout(container_);
  containerLayout_->setContentsMargins(0, 0, 0, 0);
  containerLayout_->setSpacing(8);
  scroll_->setWidget(container_);
  layout->addWidget(scroll_, 1);
  currentSubsystem_ = QStringLiteral("navigation");
  currentLeafId_ = QStringLiteral("N0.1");
}

void ExperimentParameterPanel::buildFor(const QString &subsystem, const QString &leafId,
const QVector<ExperimentParameterField> &fields,
const QMap<QString, std::shared_ptr<YamlStore>> &stores) {
  currentSubsystem_ = subsystem;
  currentLeafId_ = leafId;
  header_->setText(QStringLiteral("%1 — %2").arg(subsystem.toUpper()).arg(leafId));
  clearWidgets();
  stores_ = stores;
  fields_ = fields;
  // Group: Akuisisi
  auto *acqGroup = newGroup(QStringLiteral("Akuisisi"));
  // Group: Identitas Run
  auto *runGroup = newGroup(QStringLiteral("Identitas Run"));
  // Group: Ground Truth
  auto *gtGroup = newGroup(QStringLiteral("Ground Truth"));
  // Group: Parameter / YAML. Staged tuning leaves can request additional
  // named subgroups (P/Q/R, timing, rejection, safety, etc.) so the left
  // workbench follows the commissioning order instead of showing one flat list.
  auto *yamlGroup = newGroup(QStringLiteral("Parameter / YAML"));
  QMap<QString,QGroupBox*> stagedGroups;
  for (const ExperimentParameterField &f : fields) {
    QWidget *target = yamlGroup;
    if (f.key == QStringLiteral("sample_rate") || f.key == QStringLiteral("duration"))
      target = acqGroup;
    else if (f.key == QStringLiteral("variation") || f.key == QStringLiteral("condition"))
      target = runGroup;
    else if (f.key.startsWith(QStringLiteral("gt_")))
      target = gtGroup;
    else if (!f.group.trimmed().isEmpty()) {
      const QString name=f.group.trimmed();
      if(!stagedGroups.contains(name)) stagedGroups[name]=newGroup(name);
      target=stagedGroups[name];
    }
    addField(target, f);
  }
  containerLayout_->addStretch(1);
}

QVariant ExperimentParameterPanel::value(const QString &key) const {
  auto it = widgets_.find(key);
  if (it == widgets_.end() || !it->line) return {};
  const QString text = it->line->text().trimmed();
  if (text.isEmpty()) return {};
  if (it->kind == QStringLiteral("float") || it->kind == QStringLiteral("int")) {
    bool ok = false;
    double v = text.toDouble(&ok);
    return ok ? QVariant(v) : QVariant();
  }
  return QVariant(text);
}

QString ExperimentParameterPanel::text(const QString &key) const {
  auto it = widgets_.find(key);
  if (it == widgets_.end() || !it->line) return QString();
  return it->line->text().trimmed();
}

void ExperimentParameterPanel::setText(const QString &key, const QString &value) {
  auto it = widgets_.find(key);
  if (it != widgets_.end() && it->line) it->line->setText(value);
}

QMap<QString, QString> ExperimentParameterPanel::runIdentity() const {
  QMap<QString, QString> out;
  for (auto it = widgets_.begin(); it != widgets_.end(); ++it) {
    const QString t = it->line ? it->line->text().trimmed() : QString();
    if (!t.isEmpty()) out[it.key()] = t;
  }
  return out;
}

QGroupBox *ExperimentParameterPanel::newGroup(const QString &title) {
  auto *box = new QGroupBox(title);
  box->setObjectName(QStringLiteral("paramGroup"));
  auto *l = new QVBoxLayout(box);
  l->setContentsMargins(6, 6, 6, 6);
  l->setSpacing(4);
  groups_ << box;
  containerLayout_->addWidget(box);
  return box;
}

void ExperimentParameterPanel::addField(QWidget *group, const ExperimentParameterField &f) {
  auto *box = qobject_cast<QGroupBox *>(group);
  if (!box) return;
  auto *l = qobject_cast<QVBoxLayout *>(box->layout());
  if (!l) return;
  auto *row = new QHBoxLayout();
  auto *label = new QLabel(f.label);
  label->setWordWrap(true);
  row->addWidget(label, 1);
  auto *edit = new QLineEdit();
  if (!f.placeholder.isEmpty()) edit->setPlaceholderText(f.placeholder);
  const auto yamlStore = stores_.value(f.yamlFileKey);
  const bool yamlBacked = yamlStore && !f.yamlPath.isEmpty();
  QVariant yamlValue;
  if (yamlBacked) yamlValue = yamlStore->get(f.yamlPath);
  auto editorText = [](const QVariant &v) {
    if (!v.isValid() || v.isNull()) return QString();
    if (v.userType() == QMetaType::Bool) return v.toBool() ? QStringLiteral("true") : QStringLiteral("false");
    if (v.userType() == QMetaType::QVariantList || v.userType() == QMetaType::QVariantMap)
      return variantJsonText(v);
    return v.toString();
  };
  if (f.kind == QStringLiteral("yaml_readonly") || f.locked) {
    edit->setReadOnly(true);
    edit->setObjectName(f.locked ? QStringLiteral("lockedParameterField")
                                 : QStringLiteral("yamlReadonlyField"));
    QString value = f.lockedValue;
    if (yamlValue.isValid()) value = editorText(yamlValue);
    if (!value.isEmpty()) edit->setText(value);
    if (f.locked) label->setText(QStringLiteral("LOCKED — %1").arg(f.label));
  } else {
    if (f.isGroundTruth) edit->setObjectName(QStringLiteral("groundTruthField"));
    else if (yamlBacked) edit->setObjectName(QStringLiteral("yamlEditableField"));
    // The editor must show the real YAML value, not merely a placeholder. This
    // makes every BAB-IV tuning leaf an auditable view of the active config.
    if (yamlValue.isValid()) edit->setText(editorText(yamlValue));
  }
  row->addWidget(edit, 1);
  l->addLayout(row);
  ParamWidget w;
  w.key = f.key;
  w.kind = f.kind;
  w.line = edit;
  widgets_[f.key] = w;
  // YAML writes happen only when editing is committed (Enter/focus-out). Using
  // textChanged here would write transient values such as "0." while typing.
  if (f.kind != QStringLiteral("yaml_readonly") && !f.locked && yamlBacked) {
    const QString fk = f.yamlFileKey;
    const QString fp = f.yamlPath;
    const QString fkind = f.kind;
    const QString fieldKey = f.key;
    connect(edit, &QLineEdit::editingFinished, this, [this, edit, fk, fp, fkind, fieldKey]() {
      auto store = stores_.value(fk);
      if (!store) return;
      const QString text = edit->text().trimmed();
      QVariant value = text;
      bool valid = true;
      if (fkind == QStringLiteral("float")) {
        bool ok = false;
        const double d = text.toDouble(&ok);
        valid = ok && std::isfinite(d);
        if (valid) value = d;
      } else if (fkind == QStringLiteral("int")) {
        bool ok = false;
        const qlonglong i = text.toLongLong(&ok);
        valid = ok;
        if (valid) value = i;
      } else if (fkind == QStringLiteral("bool")) {
        const QString low = text.toLower();
        if (low == QStringLiteral("true") || low == QStringLiteral("1") ||
            low == QStringLiteral("on") || low == QStringLiteral("yes")) value = true;
        else if (low == QStringLiteral("false") || low == QStringLiteral("0") ||
                 low == QStringLiteral("off") || low == QStringLiteral("no")) value = false;
        else valid = false;
      }
      if (!valid) {
        edit->setToolTip(QStringLiteral("Nilai tidak valid untuk tipe %1; YAML tidak diubah.").arg(fkind));
        const QVariant current = store->get(fp);
        if (current.isValid()) {
          if (current.userType() == QMetaType::Bool) edit->setText(current.toBool() ? QStringLiteral("true") : QStringLiteral("false"));
          else edit->setText(current.toString());
        }
        return;
      }
      QString error;
      if (!store->set(fp, value, &error)) {
        edit->setToolTip(QStringLiteral("Gagal menyimpan YAML: %1").arg(error));
        return;
      }
      edit->setToolTip(QStringLiteral("Tersimpan ke %1\n%2").arg(store->path(), fp));
      emit parameterEdited(fieldKey, value);
      emit yamlParameterCommitted(fk, fp, value);
    });
  } else if (f.kind != QStringLiteral("yaml_readonly") && !f.locked) {
    connect(edit, &QLineEdit::textChanged, this, [this, f](const QString &t) {
      emit parameterEdited(f.key, t);
    });
  }
}

void ExperimentParameterPanel::clearWidgets() {
  for (QGroupBox *g : groups_) {
    g->deleteLater();
  }
  groups_.clear();
  widgets_.clear();
}
