
import argparse
import inspect
import json
import sys
import traceback
import warnings
from pathlib import Path

# PyTorch 2.8 warns that the TorchScript exporter will be superseded in 2.9.
# For this official YOLOPv2 TorchScript artifact we intentionally keep
# dynamo=False for compatibility and suppress only these two known notices.
warnings.filterwarnings(
    "ignore",
    category=DeprecationWarning,
    message=r"You are using the legacy TorchScript-based ONNX export.*",
)
warnings.filterwarnings(
    "ignore",
    category=UserWarning,
    message=r"no signature found for <torch\.ScriptMethod.*",
)

OUTPUT_NAMES = [
    "det_stride_8", "det_stride_16", "det_stride_32",
    "anchor_stride_8", "anchor_stride_16", "anchor_stride_32",
    "drivable", "lane",
]


def log(message):
    print(f"[YOLOPv2 OFFICIAL CONVERTER] {message}", flush=True)


def load_pytorch_model(pt_path):
    import torch
    errors = []
    try:
        model = torch.jit.load(str(pt_path), map_location="cpu")
        log("Model dibaca sebagai TorchScript resmi YOLOPv2.")
        return model
    except Exception as error:
        errors.append("torch.jit.load: " + repr(error))
    try:
        try:
            checkpoint = torch.load(str(pt_path), map_location="cpu", weights_only=False)
        except TypeError:
            checkpoint = torch.load(str(pt_path), map_location="cpu")
        if isinstance(checkpoint, torch.nn.Module):
            return checkpoint
        if isinstance(checkpoint, dict):
            for key in ("ema", "model", "module", "network", "net"):
                candidate = checkpoint.get(key)
                if isinstance(candidate, torch.nn.Module):
                    log(f"Model diambil dari checkpoint['{key}'].")
                    return candidate
    except Exception as error:
        errors.append("torch.load: " + repr(error))
    raise RuntimeError("Model .pt tidak dapat dimuat:\n  - " + "\n  - ".join(errors))


def expected_shapes(h, w):
    return {
        "det_stride_8": (1, 255, h // 8, w // 8),
        "det_stride_16": (1, 255, h // 16, w // 16),
        "det_stride_32": (1, 255, h // 32, w // 32),
        "anchor_stride_8": (1, 3, 1, 1, 2),
        "anchor_stride_16": (1, 3, 1, 1, 2),
        "anchor_stride_32": (1, 3, 1, 1, 2),
        "drivable": (1, 2, h, w),
        "lane": (1, 1, h, w),
    }


def extract_official_outputs(output, h, w):
    """Kontrak persis dari demo.py: [pred, anchor_grid], seg, ll = model(img)."""
    import torch
    if not isinstance(output, (list, tuple)) or len(output) != 3:
        raise RuntimeError(
            "Output root bukan struktur resmi YOLOPv2 3-item: ([pred,anchor_grid], seg, ll)."
        )
    det_pack, seg, lane = output
    if not isinstance(det_pack, (list, tuple)) or len(det_pack) != 2:
        raise RuntimeError("Output deteksi bukan [pred, anchor_grid] resmi YOLOPv2.")
    pred, anchor_grid = det_pack
    if not isinstance(pred, (list, tuple)) or len(pred) != 3:
        raise RuntimeError("pred harus berisi tepat 3 detection head stride 8/16/32.")
    if not isinstance(anchor_grid, (list, tuple)) or len(anchor_grid) != 3:
        raise RuntimeError("anchor_grid harus berisi tepat 3 tensor stride 8/16/32.")

    outputs = tuple(pred) + tuple(anchor_grid) + (seg, lane)
    if len(outputs) != 8 or not all(isinstance(t, torch.Tensor) for t in outputs):
        raise RuntimeError("Semua 8 output resmi YOLOPv2 harus berupa torch.Tensor.")

    shapes = expected_shapes(h, w)
    for name, tensor in zip(OUTPUT_NAMES, outputs):
        actual = tuple(int(v) for v in tensor.shape)
        if actual != shapes[name]:
            raise RuntimeError(f"Shape PT {name} salah: {actual} != {shapes[name]}")
        if not torch.isfinite(tensor.detach().float()).all():
            raise RuntimeError(f"Output PT {name} mengandung NaN/Inf.")
        log(f"PT {name}: shape={actual} dtype={tensor.dtype}")
    return outputs


class YolopV2OfficialOutputWrapper:
    @staticmethod
    def create(model):
        import torch

        class Wrapper(torch.nn.Module):
            def __init__(self, inner):
                super().__init__()
                self.inner = inner

            def forward(self, images):
                output = self.inner(images)
                det_pack = output[0]
                pred = det_pack[0]
                anchors = det_pack[1]
                return (
                    pred[0], pred[1], pred[2],
                    anchors[0], anchors[1], anchors[2],
                    output[1], output[2],
                )

        return Wrapper(model)


def static_shape(value_info):
    dims = []
    for d in value_info.type.tensor_type.shape.dim:
        dims.append(int(d.dim_value) if d.HasField("dim_value") else None)
    return dims


def _rename_graph_tensor(graph, old_name, new_name):
    """Rename one ONNX tensor everywhere without changing graph numerics."""
    if old_name == new_name:
        return
    for node in graph.node:
        for i, value in enumerate(node.input):
            if value == old_name:
                node.input[i] = new_name
        for i, value in enumerate(node.output):
            if value == old_name:
                node.output[i] = new_name
    for collection in (graph.input, graph.output, graph.value_info):
        for value_info in collection:
            if value_info.name == old_name:
                value_info.name = new_name
    for initializer in graph.initializer:
        if initializer.name == old_name:
            initializer.name = new_name
    # Sparse initializers are uncommon here, but keep the renamer complete.
    for sparse in graph.sparse_initializer:
        if sparse.values.name == old_name:
            sparse.values.name = new_name
        if sparse.indices.name == old_name:
            sparse.indices.name = new_name


def normalize_onnx_output_names(path):
    """
    PyTorch legacy ONNX export may ignore output_names for constant outputs.
    YOLOPv2 anchor_grid tensors are constants, so names such as 774/775/776
    can appear even though output_names was supplied. The tuple order remains
    the explicit Wrapper.forward order, therefore normalize names by position.
    This is metadata-only and does not modify tensor values or operators.
    """
    import onnx
    model = onnx.load(str(path))
    onnx.checker.check_model(model)
    actual_names = [o.name for o in model.graph.output]
    if len(actual_names) != len(OUTPUT_NAMES):
        raise RuntimeError(
            f"Jumlah output ONNX berubah: {len(actual_names)} != {len(OUTPUT_NAMES)}; "
            f"outputs={actual_names}"
        )
    if actual_names == OUTPUT_NAMES:
        return

    # Avoid accidental collision with an unrelated internal tensor name.
    all_tensor_names = set()
    for node in model.graph.node:
        all_tensor_names.update(v for v in node.input if v)
        all_tensor_names.update(v for v in node.output if v)
    all_tensor_names.update(v.name for v in model.graph.input)
    all_tensor_names.update(v.name for v in model.graph.output)
    all_tensor_names.update(v.name for v in model.graph.value_info)
    all_tensor_names.update(v.name for v in model.graph.initializer)

    rename_pairs = [(old, new) for old, new in zip(actual_names, OUTPUT_NAMES) if old != new]
    for old, new in rename_pairs:
        if new in all_tensor_names and new not in actual_names:
            raise RuntimeError(
                f"Tidak aman menormalisasi output ONNX {old}->{new}: nama tujuan sudah dipakai internal."
            )

    # Two-phase rename prevents collisions when an old name equals another desired name.
    temporary_pairs = []
    for index, (old, new) in enumerate(rename_pairs):
        temporary = f"__yolopv2_v19_output_{index}__"
        while temporary in all_tensor_names:
            temporary += "_"
        _rename_graph_tensor(model.graph, old, temporary)
        all_tensor_names.discard(old)
        all_tensor_names.add(temporary)
        temporary_pairs.append((temporary, new))
    for temporary, new in temporary_pairs:
        _rename_graph_tensor(model.graph, temporary, new)

    normalized_names = [o.name for o in model.graph.output]
    if normalized_names != OUTPUT_NAMES:
        raise RuntimeError(f"Normalisasi nama output ONNX gagal: {normalized_names}")
    onnx.checker.check_model(model)
    onnx.save(model, str(path))
    log(
        "Nama output ONNX dinormalisasi metadata-only: "
        + "; ".join(f"{old}->{new}" for old, new in rename_pairs)
    )


def validate_onnx_structure(path, h, w):
    import onnx
    model = onnx.load(str(path))
    onnx.checker.check_model(model)
    try:
        model = onnx.shape_inference.infer_shapes(model)
    except Exception as error:
        log(f"Shape inference warning: {error}")
    outputs = {o.name: static_shape(o) for o in model.graph.output}
    inputs = {i.name: static_shape(i) for i in model.graph.input}
    log("Input ONNX: " + "; ".join(f"{k}={v}" for k, v in inputs.items()))
    log("Output ONNX: " + "; ".join(f"{k}={v}" for k, v in outputs.items()))
    if inputs.get("images") != [1, 3, h, w]:
        raise RuntimeError(f"Input ONNX images salah: {inputs.get('images')} != {[1,3,h,w]}")
    if list(outputs.keys()) != OUTPUT_NAMES:
        raise RuntimeError(f"Nama/urutan output ONNX berubah: {list(outputs.keys())}")
    shapes = expected_shapes(h, w)
    for name in OUTPUT_NAMES:
        if outputs.get(name) != list(shapes[name]):
            raise RuntimeError(f"Shape ONNX {name} salah: {outputs.get(name)} != {list(shapes[name])}")
    return model


def parity_path(prefix, suffix):
    return Path(str(prefix) + suffix)


def make_parity_input(h, w):
    import torch
    torch.manual_seed(20260811)
    # Domain input setelah preprocessing resmi: RGB NCHW float dalam [0,1].
    return torch.rand((1, 3, h, w), dtype=torch.float32)


def save_pt_parity_reference(model, h, w, prefix):
    import numpy as np
    import torch
    x_cpu = make_parity_input(h, w)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        log(f"PT parity reference: CUDA aktif ({torch.cuda.get_device_name(0)}) FP32")
    else:
        log("PT parity reference: CUDA tidak tersedia; fallback CPU FP32")
    model_ref = model.to(device=device, dtype=torch.float32).eval()
    x_dev = x_cpu.to(device=device, dtype=torch.float32)
    with torch.no_grad():
        outputs_dev = extract_official_outputs(model_ref(x_dev), h, w)
    outputs = tuple(t.detach().cpu().float() for t in outputs_dev)
    x_cpu.numpy().astype(np.float32).tofile(parity_path(prefix, ".input.f32"))
    for name, tensor in zip(OUTPUT_NAMES, outputs):
        tensor.numpy().astype(np.float32).tofile(parity_path(prefix, f".{name}.f32"))
    metadata = {
        "input_shape": [1, 3, h, w],
        "output_names": OUTPUT_NAMES,
        "output_shapes": {k: list(v) for k, v in expected_shapes(h, w).items()},
        "seed": 20260811,
        "pt_reference_device": str(device),
        "pt_reference_dtype": "float32",
    }
    parity_path(prefix, ".meta.json").write_text(json.dumps(metadata, indent=2))
    log(f"Reference parity PT tersimpan: {prefix}.*")
    return x_cpu, outputs


def compare_arrays(name, expected, actual, precision, is_anchor=False):
    import numpy as np
    expected = np.asarray(expected, dtype=np.float32).reshape(-1)
    actual = np.asarray(actual, dtype=np.float32).reshape(-1)
    if expected.size != actual.size:
        raise RuntimeError(f"Parity {name}: jumlah elemen beda {actual.size} != {expected.size}")
    if not np.isfinite(actual).all():
        raise RuntimeError(f"Parity {name}: TensorRT mengandung NaN/Inf")
    diff = actual - expected
    abs_diff = np.abs(diff)
    rmse = float(np.sqrt(np.mean(diff * diff))) if diff.size else 0.0
    ref_rms = float(np.sqrt(np.mean(expected * expected))) if expected.size else 0.0
    nrmse = rmse / max(ref_rms, 1.0e-3)
    p99 = float(np.percentile(abs_diff, 99.0)) if abs_diff.size else 0.0
    ref_p99 = float(np.percentile(np.abs(expected), 99.0)) if expected.size else 0.0
    p99_norm = p99 / max(ref_p99, 1.0)
    max_abs = float(abs_diff.max()) if abs_diff.size else 0.0

    if is_anchor:
        ok = bool(np.allclose(actual, expected, rtol=1.0e-5, atol=1.0e-4))
        limit_text = "allclose(rtol=1e-5, atol=1e-4)"
    elif precision == "fp32":
        ok = nrmse <= 0.003 and p99_norm <= 0.010
        limit_text = "NRMSE<=0.003, P99norm<=0.010"
    else:
        # FP16 adalah jalur resmi CUDA demo.py. Toleransi ini menangkap regresi
        # besar tanpa menuntut bit-identik terhadap referensi PT float32 CPU.
        ok = nrmse <= 0.035 and p99_norm <= 0.080
        limit_text = "NRMSE<=0.035, P99norm<=0.080"

    log(
        f"PARITY {name}: NRMSE={nrmse:.6g} P99abs={p99:.6g} "
        f"P99norm={p99_norm:.6g} MAXabs={max_abs:.6g} -> {'PASS' if ok else 'FAIL'} "
        f"({limit_text})"
    )
    if not ok:
        raise RuntimeError(f"Numerical parity gagal pada output {name}")


def maybe_validate_onnxruntime(onnx_path, x, pt_outputs):
    try:
        import numpy as np
        import onnxruntime as ort
    except Exception:
        log("onnxruntime tidak tersedia; PT->ONNX numerical check dilewati. PT->TensorRT parity tetap wajib.")
        return
    available = ort.get_available_providers()
    providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if "CUDAExecutionProvider" in available else ["CPUExecutionProvider"]
    log("ONNX Runtime parity provider: " + ",".join(providers))
    session = ort.InferenceSession(str(onnx_path), providers=providers)
    ort_outputs = session.run(OUTPUT_NAMES, {"images": x.numpy().astype(np.float32)})
    for name, pt_tensor, ort_tensor in zip(OUTPUT_NAMES, pt_outputs, ort_outputs):
        expected = pt_tensor.detach().cpu().float().numpy()
        if not np.allclose(expected, ort_tensor, rtol=2.0e-4, atol=2.0e-5):
            diff = np.abs(expected - ort_tensor)
            raise RuntimeError(
                f"PT->ONNX parity gagal {name}: max_abs={float(diff.max())}, mean_abs={float(diff.mean())}"
            )
    log("PT -> ONNX numerical parity: PASS (onnxruntime).")


def export_onnx(args):
    import torch
    log(f"Python={sys.executable} PyTorch={torch.__version__}")
    log("ONNX graph export: FP32 static [1,3,384,640]; CUDA dipakai untuk reference parity bila tersedia.")
    log(f"PT={args.pt} ONNX={args.onnx} input=[1,3,{args.height},{args.width}] opset={args.opset}")
    if (args.batch, args.channels, args.height, args.width) != (1, 3, 384, 640):
        raise RuntimeError("YOLOPv2 official geometry wajib [1,3,384,640].")
    torch.set_grad_enabled(False)
    model = load_pytorch_model(Path(args.pt)).float().cpu().eval()
    dummy = torch.zeros((1, 3, args.height, args.width), dtype=torch.float32)
    with torch.no_grad():
        extract_official_outputs(model(dummy), args.height, args.width)

    wrapper = YolopV2OfficialOutputWrapper.create(model).eval()
    # Trace hanya wrapper I/O flatten; numerik inner model tetap berasal dari model resmi.
    traced = torch.jit.trace(wrapper, dummy, strict=False).eval()
    with torch.no_grad():
        traced_outputs = traced(dummy)
    shapes = expected_shapes(args.height, args.width)
    for name, tensor in zip(OUTPUT_NAMES, traced_outputs):
        if tuple(int(v) for v in tensor.shape) != shapes[name]:
            raise RuntimeError(f"Trace wrapper mengubah shape {name}: {tuple(tensor.shape)}")

    params = inspect.signature(torch.onnx.export).parameters
    kwargs = dict(
        export_params=True,
        opset_version=args.opset,
        do_constant_folding=True,
        input_names=["images"],
        output_names=OUTPUT_NAMES,
        dynamic_axes=None,
    )
    if "dynamo" in params:
        kwargs["dynamo"] = False
    try:
        torch.onnx.export(traced, dummy, args.onnx, **kwargs)
    except Exception:
        log(traceback.format_exc())
        raise

    normalize_onnx_output_names(Path(args.onnx))
    validate_onnx_structure(Path(args.onnx), args.height, args.width)
    if args.simplify:
        try:
            import onnx
            from onnxsim import simplify
            original = onnx.load(args.onnx)
            simplified, ok = simplify(original)
            if not ok:
                raise RuntimeError("onnxsim check=False")
            onnx.save(simplified, args.onnx)
            normalize_onnx_output_names(Path(args.onnx))
            validate_onnx_structure(Path(args.onnx), args.height, args.width)
            log("ONNX simplification valid (opsional, bukan default).")
        except Exception as error:
            raise RuntimeError(f"Simplifikasi diminta tetapi gagal: {error}")

    if args.validate:
        x, pt_outputs = save_pt_parity_reference(model, args.height, args.width, args.parity_prefix)
        maybe_validate_onnxruntime(Path(args.onnx), x, pt_outputs)
    log(f"ONNX VALID: {Path(args.onnx).stat().st_size/(1024*1024):.2f} MiB")


def load_trtexec_json(path):
    payload = json.loads(Path(path).read_text())
    if isinstance(payload, dict):
        for key in ("outputs", "tensors", "data"):
            if isinstance(payload.get(key), list):
                payload = payload[key]
                break
    if not isinstance(payload, list):
        raise RuntimeError("Format JSON --exportOutput trtexec tidak dikenali.")
    records = {}
    for item in payload:
        if not isinstance(item, dict) or "name" not in item:
            continue
        records[str(item["name"])] = item
    return records


def compare_trt(args):
    import numpy as np
    prefix = Path(args.parity_prefix)
    meta_path = parity_path(prefix, ".meta.json")
    if not meta_path.is_file():
        raise RuntimeError(f"Metadata parity PT tidak ditemukan: {meta_path}")
    meta = json.loads(meta_path.read_text())
    if meta.get("output_names") != OUTPUT_NAMES:
        raise RuntimeError("Metadata parity output names tidak sesuai kontrak V19.")
    records = load_trtexec_json(args.trt_json)
    missing = [name for name in OUTPUT_NAMES if name not in records]
    if missing:
        raise RuntimeError(f"TensorRT exportOutput tidak memiliki output: {missing}")

    for name in OUTPUT_NAMES:
        expected_shape = tuple(meta["output_shapes"][name])
        item = records[name]
        dims = item.get("dimensions", item.get("shape", []))
        if tuple(int(v) for v in dims) != expected_shape:
            raise RuntimeError(f"TensorRT shape {name} salah: {dims} != {expected_shape}")
        values = item.get("values")
        if not isinstance(values, list):
            raise RuntimeError(f"TensorRT JSON {name} tidak memiliki array values.")
        expected = np.fromfile(parity_path(prefix, f".{name}.f32"), dtype=np.float32)
        actual = np.asarray(values, dtype=np.float32)
        compare_arrays(name, expected, actual, args.precision, name.startswith("anchor_stride_"))
    log("PT -> TensorRT end-to-end numerical parity: PASS untuk seluruh 8 output.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=("export", "compare"), default="export")
    ap.add_argument("--pt")
    ap.add_argument("--onnx")
    ap.add_argument("--batch", type=int, default=1)
    ap.add_argument("--channels", type=int, default=3)
    ap.add_argument("--height", type=int, default=384)
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--opset", type=int, default=17)
    ap.add_argument("--simplify", action="store_true")
    ap.add_argument("--validate", action="store_true")
    ap.add_argument("--parity-prefix", required=True)
    ap.add_argument("--trt-json")
    ap.add_argument("--precision", choices=("fp16", "fp32"), default="fp16")
    args = ap.parse_args()
    if args.mode == "export":
        if not args.pt or not args.onnx:
            ap.error("--pt dan --onnx wajib untuk mode export")
        export_onnx(args)
    else:
        if not args.trt_json:
            ap.error("--trt-json wajib untuk mode compare")
        compare_trt(args)


if __name__ == "__main__":
    main()
